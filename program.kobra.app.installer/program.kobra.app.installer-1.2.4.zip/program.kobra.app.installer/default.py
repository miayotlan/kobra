################################################################################
#                                                                              #
#                        Copyright (C) 2017 Kobra                              #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
#      Thanks to Surfacingx, ][NT3L][G3NC][, WHUFCLEE, Midraal, OpenELEQ       #
#                      anyone else I may have missed.                          #
#                                                                              #
################################################################################


import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs
import shutil
import urllib2, urllib
import re
import time

from resources.libs import downloader, extract


T                   = time.sleep
X                   = xbmc.executebuiltin
DP                  = xbmcgui.DialogProgress()
DIVIDE              = '[COLOR lime]-------------------------------------------------------------------------------------------------------[/COLOR]'
USER_AGENT          = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID            = 'program.kobra.app.installer'
ADDON               = xbmcaddon.Addon(id=ADDON_ID)
DIALOG              = xbmcgui.Dialog()
ADDON_TITLE2        = "[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  APP INSTALLER[/COLOR]"
ADDON_TITLE3        = "[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  FILE CLEANER[/COLOR]"
FANART              = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
FANART1             = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'resources/art/fanart/fanart1.jpg'))
FANART2             = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'resources/art/fanart/fanart2.jpg'))
FANART3             = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'resources/art/fanart/fanart3.jpg'))
ART                 = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID + '/resources/art/android/'))
ART1                = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID + '/resources/art/windows/'))
ART2                = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID + '/resources/art/linux/'))
VERSION             = "1.2.4"
PATH                = "Kobra Installer"            
BASEURL             = "http://"
HOME                = xbmc.translatePath('special://home/')
ADDONS              = os.path.join(HOME,     'addons')
PACKAGES            = os.path.join(ADDONS,   'packages') 
DOWNLOADPATH        = ADDON.getSetting('downloads')
ROM_PATH            = os.path.join(DOWNLOADPATH, 'ROMs')
ROM_PACKS_PATH      = os.path.join(DOWNLOADPATH, 'ROMs', 'Rom_Packs')
ADULT               = ADDON.getSetting('adult')


###################
#### MAIN MENU ####
###################

def index1():
    if xbmc.getCondVisibility('system.platform.windows'): 
        addDir('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  INSTALLER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
        addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
        addDir('[COLOR ghostwhite]Apps[/COLOR]',BASEURL,6,ART+'appsmenu.png',FANART,'')
        addDir('[COLOR ghostwhite]Roms[/COLOR]',BASEURL,23,ART+'romssingle.png',FANART,'')
        addDir('[COLOR ghostwhite]Emulators[/COLOR]',BASEURL,7,ART+'emulatorsmenu.png',FANART,'')
        if ADULT == 'true':
            addDir('[COLOR ghostwhite]Adult Apps[/COLOR]',BASEURL,9,ART+'adultapps.png',FANART,'')
        addDir('[COLOR ghostwhite]Custom Kodi/Spmc Forks[/COLOR]',BASEURL,14,ART+'kodispmcforks.png',FANART,'')
        addDir('[COLOR ghostwhite]User Requests[/COLOR]',BASEURL,13,ART+'requestsmenu.png',FANART,'')
        addDir('[COLOR ghostwhite]Open Settings[/COLOR]',BASEURL,4,ART+'opensettings.png',FANART,'')
        setView('files', 'MAIN')
    else: 
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  INSTALLER[/COLOR]"," "," ","[COLOR ghostwhite]Sorry, [/COLOR][COLOR lime][I]Kobra[/I][/COLOR][COLOR ghostwhite]  Installer is not yet available for your device[/COLOR]")


#####################
#### ROMS MENU 2 ####
#####################

def rom_menu_1():
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]INSTALLER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    addDir('[COLOR ghostwhite]Roms[/COLOR]',BASEURL,12,ART+'romssingle.png',FANART,'')
    addDir('[COLOR ghostwhite]Rom Apps[/COLOR]',BASEURL,15,ART+'romapps.png',FANART,'')
    addDir('[COLOR ghostwhite]Rom Packs[/COLOR]',BASEURL,3,ART+'rompacks.png',FANART,'')
    setView('files', 'MAIN')


#####################
#### ROMS MENU 1 ####
#####################

def rom_menu_2():
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]ROMS DOWNLOADER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    addDir('[COLOR ghostwhite]Sega Genesis/Megadrive[/COLOR]',BASEURL,17,'http://kobracustombuilds.com/rompacks/img/genesis.png',FANART,'')
    addDir('[COLOR ghostwhite]Super Nintendo Entertainment Sysyem (SNES)[/COLOR]',BASEURL,18,'http://kobracustombuilds.com/rompacks/img/snes.jpg',FANART,'')
    addDir('[COLOR ghostwhite]Nintendo Entertainment Sysyem (NES)[/COLOR]',BASEURL,19,'http://kobracustombuilds.com/rompacks/img/nes.jpg',FANART,'')
    setView('files', 'MAIN')


################
### APPS URL ###
################

def apps_wizard():
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]APP INSTALLER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    link = open_url('http://kobracustombuilds.com/apks/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,5,iconimage,fanart,description)

    # DaButcher url

    link2 = open_url('http://dabutcher.org/tools/apkwizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link2)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,5,iconimage,fanart,description)
    setView('files', 'MAIN')


######################
### ADULT APPS URL ###
######################

def adult_apps_url():
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]ADULT APP INSTALLER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    link = open_url('http://kobracustombuilds.com/adult/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,10,iconimage,fanart,description)

    # DaButcher url

    link2 = open_url('http://dabutcher.org/tools/adultapkwizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link2)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,10,iconimage,fanart,description)
    setView('files', 'MAIN')


#######################
### CUSTOM APPS URL ###
#######################

def custom_apps_url():
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]CUSTOM KODI/SPMC INSTALLER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    link = open_url('http://kobracustombuilds.com/apks/wizard/customapkswizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,5,iconimage,fanart,description)
    setView('files', 'MAIN')


#####################
### ROM PACKS URL ###
#####################

def rom_packs():
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]ROM PACK INSTALLER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    link = open_url('http://kobracustombuilds.com/rompacks/wizard/rompacks.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,11,iconimage,fanart,description)
    setView('files', 'MAIN')


#############################
### SEGA GENESIS ROMS URL ###
#############################

def sega_genesis_roms():
    base_url = 'http://youknowhim.com/Roms/GENESIS-COMPLETE%20COLLECTION_700%20ROMS/GEN_723%20ROMS/'
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]ROMS DOWNLOADER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    link = open_url(base_url).replace('\n','').replace('\r','')

# Grab the whole section consisting of url and name, we can then split this up in python
    match = re.compile('href="(.+?)</a>').findall(link)
    for item in match:
# Make sure the item is a valid zip
        if '.zip' in item:
# Split the string at a specific point so we end up with 2 strings (url and name)
            url, name = item.split('">')
            url = base_url+url
            name = cleanup_name(base_url, url)
            addDir(name,url,20,'http://kobracustombuilds.com/rompacks/img/genesis.png','http://kobracustombuilds.com/roms/fanart/android.jpg','')
    setView('files', 'MAIN')


def cleanup_name(base_url, name):
    name = name.replace(base_url,'')
    name = urllib.unquote_plus(name)
    name = name.replace('.zip','')
    return name


###############################
### SUPER NINTENDO ROMS URL ###
###############################

def super_nintendo_roms():
    base_url = 'http://youknowhim.com/Roms/SUPER%20NINTENDO-COMPLETE%20COLLECTION_700%20ROMS/SNES_763%20ROMS/'
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]ROMS DOWNLOADER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    link = open_url(base_url).replace('\n','').replace('\r','')

# Grab the whole section consisting of url and name, we can then split this up in python
    match = re.compile('href="(.+?)</a>').findall(link)
    for item in match:
# Make sure the item is a valid zip
        if '.zip' in item:
# Split the string at a specific point so we end up with 2 strings (url and name)
            url, name = item.split('">')
            url = base_url+url
            name = cleanup_name(base_url, url)
            addDir(name,url,21,'http://kobracustombuilds.com/rompacks/img/snes.jpg','http://kobracustombuilds.com/roms/fanart/android.jpg','')
    setView('files', 'MAIN')


####################
### NES ROMS URL ###
####################

def nes_roms():
    base_url = 'http://youknowhim.com/Roms/NINTENDO-COMPLETE%20COLLECTION_1000%20ROMS/NES_1,090%20ROMS/'
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]ROMS DOWNLOADER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    link = open_url(base_url).replace('\n','').replace('\r','')

# Grab the whole section consisting of url and name, we can then split this up in python
    match = re.compile('href="(.+?)</a>').findall(link)
    for item in match:
# Make sure the item is a valid zip
        if '.zip' in item:
# Split the string at a specific point so we end up with 2 strings (url and name)
            url, name = item.split('">')
            url = base_url+url
            name = cleanup_name(base_url, url)
            addDir(name,url,22,'http://kobracustombuilds.com/rompacks/img/nes.jpg','http://kobracustombuilds.com/roms/fanart/android.jpg','')
    setView('files', 'MAIN')


########################
### EMULATORS WIZARD ###
########################

def emulator_wizard():
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]EMULATOR INSTALLER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    link = open_url('http://kobracustombuilds.com/emulators/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,8,iconimage,fanart,description)

    # DaButcher url

    link2 = open_url('http://dabutcher.org/tools/emulatorapkwizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link2)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,8,iconimage,fanart,description)
    setView('files', 'MAIN')


#######################
### ROM APPS WIZARD ###
#######################

def rom_apps_wizard():
    addDir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]ROM APP INSTALLER[/COLOR]','noop',0,ART+'kobraappinstaller.png',FANART,'')
    addDir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    link = open_url('http://kobracustombuilds.com/roms/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,16,iconimage,fanart,description)

    # DaButcher url

    link2 = open_url('http://dabutcher.org/tools/romswizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link2)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,16,iconimage,fanart,description)
    setView('files', 'MAIN')   


############################
#### APPS INSTALL ##########
############################
# THANKS TO ][NT3L][G3NC][ #
############################

def app_install(name,url,description):
    if DIALOG.yesno(name,description,"","","[COLOR orange]GO BACK[/COLOR]","[COLOR lime]INSTALL[/COLOR]"):
        downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  APP INSTALLER[/COLOR]")
        lib=os.path.join(downloadpath, name+'.apk')
        downloader.download(url, lib, DP)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        DP.close()
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  APP INSTALLER[/COLOR]","Download complete.","","Click OK to install " + name + "") 
        X('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
        T(4)
        clean_up()
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  APP INSTALLER[/COLOR]"," "," ","Thanks for using [COLOR lime][I]Kobra[/I][/COLOR][COLOR ghostwhite]  App Installer[/COLOR]")
    else: pass


##########################
#### EMULATOR INSTALL ####
##########################

def emulator_install(name,url,description):
    if DIALOG.yesno(name,description,"","","[COLOR orange]GO BACK[/COLOR]","[COLOR lime]INSTALL[/COLOR]"):
        downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))#
        DP.create("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  EMULATOR INSTALLER INSTALLER[/COLOR]")
        lib=os.path.join(downloadpath, name+'.apk')
        downloader.download(url, lib, DP)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        DP.close()
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  EMULATOR INSTALLER[/COLOR]","Download complete.","","Click OK to install " + name + "")
        X('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
        T(4)
        clean_up()
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  EMULATOR INSTALLER[/COLOR]"," "," ","Thanks for using [COLOR lime][I]Kobra[/I][/COLOR][COLOR ghostwhite]  App Installer[/COLOR]")
    else: pass


###########################
#### ROMS APPS INSTALL ####
###########################

def rom_apps_install(name,url,description):
    if DIALOG.yesno(name,description,"","","[COLOR orange]GO BACK[/COLOR]","[COLOR lime]INSTALL[/COLOR]"):
        downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM APP INSTALLER[/COLOR]")
        lib=os.path.join(downloadpath, name+'.apk')
        downloader.download(url, lib, DP)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        DP.close()
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM APP INSTALLER[/COLOR]","Download complete.","","Click OK to install " + name + "")
        X('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
        T(4)
        clean_up()
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM APP INSTALLER[/COLOR]"," "," ","Thanks for using [COLOR lime][I]Kobra[/I][/COLOR][COLOR ghostwhite]  App Installer[/COLOR]")
    else: pass


############################
#### ROMS PACKS INSTALL ####
############################

def rom_packs_install(name,url,description):
    if DOWNLOADPATH == '' or not os.path.exists(DOWNLOADPATH): 
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM PACK INSTALLER[/COLOR]", "[COLOR ghostwhite][CR]You will need to setup a downloads path before you can download any Rom Packs. Click OK to continue[/COLOR]")
        settings(ADDON_ID, 1.0, True)
    else:
        if DIALOG.yesno("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM PACK INSTALLER[/COLOR]",description,"","","[COLOR orange]GO BACK[/COLOR]","[COLOR lime]DOWNLOAD[/COLOR]"):
            DP.create("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM PACK INSTALLER[/COLOR]")
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'ROMs', 'Rom_Packs')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'ROMs', 'Rom_Packs'))
                except: DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM PACK INSTALLER[/COLOR]" '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]'); setS('downloads', ""); ADDON.openSettings(); return
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'ROMs', 'Rom_Packs')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'ROMs', 'Rom_Packs'))
                except: DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM PACK INSTALLER[/COLOR]" '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]', '[COLOR ghostwhite]Failed to create[/COLOR]: %s' % os.path.join(DOWNLOADPATH, 'ROMs', 'Rom_Packs'));  return
            lib=os.path.join(DOWNLOADPATH, 'ROMs', 'Rom_Packs', name+'.zip')
            downloader.download(url, lib, DP)
            T(2)
            DP.update(0,"[COLOR ghostwhite]Download complete[/COLOR]", "")
            T(1)
            DP.update(0,"","[COLOR ghostwhite]Extracting rom pack[/COLOR]")
            extract.all(lib,ROM_PACKS_PATH,DP)
            T(1)
            DP.close()
            try: os.remove(lib)
            except: pass
            DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM PACK INSTALLER[/COLOR]", "[COLOR ghostwhite][CR]Rom pack successfully downloaded. Click OK to continue[/COLOR]")
        else: pass


############################
#### SEGA ROMS DOWNLOAD ####
############################

def sega_rom_download(name,url,description):
    if DOWNLOADPATH == '' or not os.path.exists(DOWNLOADPATH): 
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]", "[COLOR ghostwhite][CR]You will need to setup a downloads path before you can download any Rom Packs. Click OK to continue[/COLOR]")
        settings(ADDON_ID, 1.0, True)
    else:
        if DIALOG.yesno("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]",name,"","Would you like to download this rom?","[COLOR orange]GO BACK[/COLOR]","[COLOR lime]DOWNLOAD[/COLOR]"):
            DP.create("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]")
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'ROMs', 'Sega_Genesis-Megadrive_Roms')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'ROMs', 'Sega_Genesis-Megadrive_Roms'))
                except: DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]" '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]'); setS('downloads', ""); ADDON.openSettings(); return
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'ROMs', 'Sega_Genesis-Megadrive_Roms')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'ROMs', 'Sega_Genesis-Megadrive_Roms'))
                except: DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]" '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]', '[COLOR ghostwhite]Failed to create[/COLOR]: %s' % os.path.join(DOWNLOADPATH, 'ROMs', 'Sega_Genesis-Megadrive_Roms'));  return
            lib=os.path.join(DOWNLOADPATH, 'ROMs', 'Sega_Genesis-Megadrive_Roms', name+'.zip')
            downloader.download(url, lib, DP)
            T(2)
            DP.close()
            DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]", "[COLOR ghostwhite][CR]Rom successfully downloaded. Click OK to continue[/COLOR]")
        else: pass



############################
#### SNES ROMS DOWNLOAD ####
############################

def snes_rom_download(name,url,description):
    if DOWNLOADPATH == '' or not os.path.exists(DOWNLOADPATH): 
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]", "[COLOR ghostwhite][CR]You will need to setup a downloads path before you can download any Rom Packs. Click OK to continue[/COLOR]")
        settings(ADDON_ID, 1.0, True)
    else:
        if DIALOG.yesno("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]",name,"","Would you like to download this rom?","[COLOR orange]GO BACK[/COLOR]","[COLOR lime]DOWNLOAD[/COLOR]"):
            DP.create("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]")
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'ROMs', 'Snes_Roms')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'ROMs', 'Snes_Roms'))
                except: DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]" '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]'); setS('downloads', ""); ADDON.openSettings(); return
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'ROMs', 'Snes_Roms')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'ROMs', 'Snes_Roms'))
                except: DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]" '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]', '[COLOR ghostwhite]Failed to create[/COLOR]: %s' % os.path.join(DOWNLOADPATH, 'ROMs', 'Snes_Roms'));  return
            lib=os.path.join(DOWNLOADPATH, 'ROMs', 'Snes_Roms', name+'.zip')
            downloader.download(url, lib, DP)
            T(2)
            DP.close()
            DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]", "[COLOR ghostwhite][CR]Rom successfully downloaded. Click OK to continue[/COLOR]")
        else: pass


###########################
#### NES ROMS DOWNLOAD ####
###########################

def nes_rom_download(name,url,description):
    if DOWNLOADPATH == '' or not os.path.exists(DOWNLOADPATH): 
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]", "[COLOR ghostwhite][CR]You will need to setup a downloads path before you can download any Rom Packs. Click OK to continue[/COLOR]")
        settings(ADDON_ID, 1.0, True)
    else:
        if DIALOG.yesno("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]",name,"","Would you like to download this rom?","[COLOR orange]GO BACK[/COLOR]","[COLOR lime]DOWNLOAD[/COLOR]"):
            DP.create("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]")
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'ROMs', 'Nes_Roms')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'ROMs', 'Nes_Roms'))
                except: DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]" '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]'); setS('downloads', ""); ADDON.openSettings(); return
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'ROMs', 'Nes_Roms')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'ROMs', 'Nes_Roms'))
                except: DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]" '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]', '[COLOR ghostwhite]Failed to create[/COLOR]: %s' % os.path.join(DOWNLOADPATH, 'ROMs', 'Nes_Roms'));  return
            lib=os.path.join(DOWNLOADPATH, 'ROMs', 'Nes_Roms', name+'.zip')
            downloader.download(url, lib, DP)
            T(2)
            DP.close()
            DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ROM DOWNLOADER[/COLOR]", "[COLOR ghostwhite][CR]Rom successfully downloaded. Click OK to continue[/COLOR]")
        else: pass


##########################
### ADULT APP INSTALL ####
##########################

def adult_app_install(name,url,description):
    if DIALOG.yesno(name,description,"","","[COLOR orange]GO BACK[/COLOR]","[COLOR lime]DOWNLOAD[/COLOR]"):
        downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))#
        DP.create("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ADULT APP INSTALLER[/COLOR]")
        lib=os.path.join(downloadpath, name+'.apk')
        downloader.download(url, lib, DP)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        DP.close()
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ADULT APP INSTALLER[/COLOR]","Download complete.","","Click ok to install " + name + "")
        X('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
        T(4)
        clean_up()
        DIALOG.ok("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ADULT APP INSTALLER[/COLOR]"," "," ","Thanks for using [COLOR lime][I]Kobra[/I][/COLOR][COLOR ghostwhite]  App Installer[/COLOR]")
    else: pass


################################
###### CLEAN UP PACKAGES #######
##### THANKS GUYS @ XUNITY ##### 
##### MODDED BY AFTERMATH ######
################################

def clean_up():
    if os.path.exists(PACKAGES):
        try:    
            for root, dirs, files in os.walk(PACKAGES):
                file_count = 0
                file_count += len(files)
                # Count files and give option to delete
                if file_count > 0:
                    if DIALOG.yesno(ADDON_TITLE3," ", "[COLOR ghostwhite]{0} files found, [CR][CR]Would you like to remove them?[/COLOR]".format(file_count),"","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, REMOVE[/COLOR]"):
                        for f in files: os.unlink(os.path.join(root, f))
                        for d in dirs: shutil.rmtree(os.path.join(root, d))
                        DIALOG.ok(ADDON_TITLE3,'[CR][CR]Clean up files: [COLOR lime] Success![/COLOR]')
                else: DIALOG.ok(ADDON_TITLE3,'[CR][CR]Clean up files: [COLOR red]None found![/COLOR]')
        except: DIALOG.ok(ADDON_TITLE3,'[CR][CR]Clean up files: [COLOR red] Error![/COLOR]')
    else: DIALOG.ok(ADDON_TITLE3,'[CR][CR]Clean up files: [COLOR red] None found![/COLOR]')


################
### SETTINGS ###
################

def open_settings():
    try:
        ADDON.openSettings()
        X('Container.Refresh')
    except:
        return

def settings(id=ADDON_ID, focus=None, click=False):
    try:
        X('Addon.OpenSettings(%s)' % id)
        value1, value2 = str(focus).split('.')
        X('SetFocus(%d)' % (int(value1) + 100))
        X('SetFocus(%d)' % (int(value2) + 200))
        if click == True: X('SendClick(%s)' % (int(value2) + 200))
    except:
        return

def getS(name):
    try: return ADDON.getSetting(name)
    except: return False

def setS(name, value):
    try: ADDON.setSetting(name, value)
    except: return False


################
### REQUESTS ###
################

def requests():
    TextBoxes("[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  APP INSTALLER[/COLOR]","[CR][COLOR ghostwhite]Please send any package requests to:[/COLOR][CR][CR][COLOR dodgerblue]FACEBOOK: https://www.facebook.com/groups/KodiCustomBuilds/ [/COLOR][COLOR red][CR][CR]YOUTUBE: https://www.youtube.com/channel/UCylDOZ_hQ7zPBoWE9gy28CA[/COLOR][CR][CR][COLOR lime]Please press back to exit[/COLOR]")
   
def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link


#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
    class TextBox():
        WINDOW=10147
        CONTROL_LABEL=1
        CONTROL_TEXTBOX=5
        def __init__(self,*args,**kwargs):
            X("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
            self.win=xbmcgui.Window(self.WINDOW) # get window
            xbmc.sleep(500) # give window time to initialize
            self.setControls()
        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
            try: f=open(announce); text=f.read()
            except: text=announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return
    TextBox()


###################
### COMING SOON ###
###################

def coming_soon_android():
    addDir('[COLOR lime]COMING SOON...[/COLOR]','noop',0,ART+'comingsoon3.png',FANART,'')
    setView('movies', 'MAIN')


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==4 or mode==5 or mode==8  or mode==10 or mode==11 or mode==13 or mode==16 or mode==20 or mode==21 or mode==22 or url=='noop':
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


params          = get_params()
url             = None
name            = None
mode            = None
iconimage       = None
fanart          = None
description     = None


try:    url=urllib.unquote_plus(params["url"])
except: pass

try:    name=urllib.unquote_plus(params["name"])
except: pass

try:    iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

try:    mode=int(params["mode"])
except: pass

try:    fanart=urllib.unquote_plus(params["fanart"])
except: pass

try:    description=urllib.unquote_plus(params["description"])
except: pass


print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), 'files')
    if ADDON.getSetting('auto-view')=='true':
        X("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )


if mode==None:  index1()

elif mode==3:   rom_packs()

elif mode==4:   open_settings()

elif mode==5:   app_install(name,url,description)

elif mode==6:   apps_wizard()

elif mode==7:   emulator_wizard()

elif mode==8:   emulator_install(name,url,description)

elif mode==9:   adult_apps_url()

elif mode==10:  adult_app_install(name,url,description)

elif mode==11:  rom_packs_install(name,url,description)

elif mode==12:  rom_menu_2()

elif mode==13:  requests()

elif mode==14:  custom_apps_url()

elif mode==15:  rom_apps_wizard()

elif mode==16:  rom_apps_install(name,url,description)

elif mode==17:  sega_genesis_roms()

elif mode==18:  super_nintendo_roms()

elif mode==19:  nes_roms()

elif mode==20:  sega_rom_download(name,url,description)

elif mode==21:  snes_rom_download(name,url,description)

elif mode==22:  nes_rom_download(name,url,description)

elif mode==23:  rom_menu_1()
        
elif mode==99:  coming_soon_android()


        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
