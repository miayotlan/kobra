import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net




USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'program.kobra.app.installer'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='program.kobra.app.installer'
AddonTitle="Kobra App Installer"
dialog       =  xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "0.0.1"
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "Kobra Wizard"            
BASEURL = "http://kodicustombuilds.com/builds"
BASEURL1 = "http://kodicustombuilds.com/builds"
BASEURL2 = "http://kodicustombuilds.com/test"
H = 'http://'

#################
### MAIN MENU ###
#################

def INDEX():
    addDir('VIDEO TUTORIALS',BASEURL,12,ART+'tutorials.png',FANART,'')
    addDir('INSTALL ES FILE EXPLORER BEFORE USE',BASEURL,9,ART+'esfileexplorer.png',FANART,'')
    addDir('APPS',BASEURL,6,ART+'apps.png',FANART,'')
    addDir('EMULATORS',BASEURL,7,ART+'emulators.png',FANART,'')
    addDir('ROMS',BASEURL,99,ART+'roms.png',FANART,'')
    addDir('ADULT APPS',BASEURL,99,ART+'adult.png',FANART,'')
    setView('movies', 'MAIN')
	
#############################
### VIDEO TUTORIALS INDEX ###
#############################
	
def VIDEOINDEX():
    addDir('ES FILE EXPLORER',BASEURL,11,ART+'amazon.png',FANART,'')
    setView('movies', 'MAIN')
	

	
################
### APPS URL ###
################

def APPSWIZARD():
    link = OPEN_URL('http://kobracustombuilds.com/apks/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,5,iconimage,fanart,description)
    setView('list', 'MAIN')
	
#####################
### EMULATORS URL ###
#####################

def EMULATORWIZARD():
    link = OPEN_URL('http://kobracustombuilds.com/emulators/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,8,iconimage,fanart,description)
    setView('list', 'MAIN')
	
############################
### ES FILE EXPLORER URL ###
############################
	
def ESFILEEXPLORER():
    link = OPEN_URL('http://kobracustombuilds.com/apks/esfileexplorer/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,10,iconimage,fanart,description)
    setView('list', 'MAIN')



#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()   
    

#########################
#### VIDEO TUTORIALS ####
#########################

def PLAYVIDEO():
    choice = xbmcgui.Dialog().yesno('[COLOR=grey][B]KOBRA VIDEO TUTORIALS[/B][/COLOR]', 'WOULD YOU LIKE TO WATCH THE VIDEO?', 'THIS VIDEO TUTORIAL WILL SHOW HOW TO INSTALL [COLOR blue]ES FILE EXPLORER[/COLOR] ON [COLOR orange]AMAZON[/COLOR] DEVICES..', nolabel='CLOSE',yeslabel='WATCH VIDEO')
    if choice == 0:
       return    
    elif choice == 1:
	   xbmc.executebuiltin("PlayMedia(http://kobracustombuilds.com/amazontutorials.mp4)")
	   
####################
####APPS INSTALL####
####################

def APPINSTALL(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno(name,description,"","","Go back","Download"):
    ###Testing on windows###
    #downloadpath = xbmc.translatePath(os.path.join('c:/users/USERNAME/desktop'))#
    downloadpath = xbmc.translatePath(os.path.join('/storage/emulated/0/download/'))
    dp = xbmcgui.DialogProgress()
    dp.create("[COLOR grey][B]KOBRA APP INSTALLER[/COLOR][/B]","Downloading...",name,'Please wait...')
    lib=os.path.join(downloadpath, name+'.apk')
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    choice = xbmcgui.Dialog().yesno('[COLOR=grey][B]DOWNLOAD COMPLETE[/B][/COLOR]', 'WOULD YOU LIKE TO INSTALL THE APPLICATION?', 'PLEASE NOTE, TO INSTALL THIS APPLICATION YOU WILL NEED [COLOR blue]ES FILE EXPLORER FILE MANAGER[/COLOR] INSTALLED ON YOUR DEVICE. THIS CAN BE DOWNLOADED FROM GOOGLE PLAY OR THE AMAZON STORE.', nolabel='CLOSE',yeslabel='INSTALL  APK')
    if choice == 0:
       return    
    elif choice == 1:
       xbmc.executebuiltin("StartAndroidActivity(com.estrongs.android.pop)")
	
#######################
###EMULATOR INSTALL####
#######################

def EMULATORINSTALL(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno(name,description,"","","Go back","Download"):
    ###Testing on windows###
    #downloadpath = xbmc.translatePath(os.path.join('c:/users/USERNAME/desktop'))#
    downloadpath = xbmc.translatePath(os.path.join('/storage/emulated/0/download/'))
    dp = xbmcgui.DialogProgress()
    dp.create("[COLOR grey][B]KOBRA EMULATOR INSTALLER[/COLOR][/B]","Downloading...",name,'Please wait...')
    lib=os.path.join(downloadpath, name+'.apk')
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    choice = xbmcgui.Dialog().yesno('[COLOR=grey][B]DOWNLOAD COMPLETE[/B][/COLOR]', 'WOULD YOU LIKE TO INSTALL THE EMULATOR?', 'PLEASE NOTE, TO INSTALL THIS APPLICATION YOU WILL NEED [COLOR blue]ES FILE EXPLORER FILE MANAGER[/COLOR] INSTALLED ON YOUR DEVICE. THIS CAN BE DOWNLOADED FROM GOOGLE PLAY OR THE AMAZON STORE.', nolabel='CLOSE',yeslabel='INSTALL  APK')
    if choice == 0:
       return    
    elif choice == 1:
       xbmc.executebuiltin("StartAndroidActivity(com.estrongs.android.pop)")
	
#######################
###ES FILE INSTALL ####
#######################
	
def ESFILEINSTALL(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno(name,description,"","","Go back","Download"):
    ###Testing on windows###
    #downloadpath = xbmc.translatePath(os.path.join('c:/users/USERNAME/desktop'))#
    downloadpath = xbmc.translatePath(os.path.join('/storage/emulated/0/download/'))
    dp = xbmcgui.DialogProgress()
    dp.create("[COLOR grey][B]APK DOWNLOAD[/COLOR][/B]","Downloading...",name,'Please wait...')
    lib=os.path.join(downloadpath, name+'.apk')
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(1)
    dialog.ok("[B][COLOR grey]Installation instructions[/B][/COLOR]","1. Exit Kodi                                                                                 2. Open Android file manager","3. Navigate to Download folder","4. Click on ES file explorer APK to install")

   
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def COMINGSOON():
    addDir('COMING SOON...',BASEURL,0,ART+'comingsoon.png',FANART,'')
    setView('movies', 'MAIN')

  
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 or mode==8 or mode==10 or mode==11:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==2:
        BUILDMENU()
		
elif mode==5:
        APPINSTALL(name,url,description)
		
elif mode==6:
        APPSWIZARD()
		
elif mode==7:
        EMULATORWIZARD()

elif mode==8:
        EMULATORINSTALL(name,url,description)

elif mode==9:
        ESFILEEXPLORER()
		
elif mode==10:		
	    ESFILEINSTALL(name,url,description)
				
elif mode==11:
        PLAYVIDEO()
		
elif mode==12:
        VIDEOINDEX()

elif mode==99:
        COMINGSOON()


        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
