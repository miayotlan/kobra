import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, base64, sys, xbmcvfs
import shutil
import urllib2, urllib
import re
import extract
import downloader
import time
import plugintools


USER_AGENT 			= 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id 			= 'program.kobra.app.installer'
ADDON 				= xbmcaddon.Addon(id=addon_id)
AddonTitle			= "Kobra App Installer"
dialog				= xbmcgui.Dialog()
AddonTitle3 		= "[COLOR lime][B][I]KOBRA[/I][/B][/COLOR][COLOR ghostwhite] [B]FILE CLEANER[/B][/COLOR]"
U 					= ADDON.getSetting('User')
FANART 				= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
FANART1 			= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'resources/art/fanart/fanart1.jpg'))
FANART2 			= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'resources/art/fanart/fanart2.jpg'))
FANART3 			= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'resources/art/fanart/fanart3.jpg'))
FANART_EMULATORS    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'resources/art/emulators.png'))
ICON 				= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon1.png'))
ART 				= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/android/'))
ART1 				= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/windows/'))
ART2 				= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/linux/'))
VERSION 			= "1.1.8"
PATH 				= "Kobra Wizard"            
BASEURL			    = "http://kodicustombuilds.com/builds"
BASEURL1 			= "http://kodicustombuilds.com/builds"
BASEURL2 			= "http://kodicustombuilds.com/test"
HOME 				= xbmc.translatePath('special://home/')
ADDONS 				= os.path.join(HOME,     'addons')
PACKAGES 			= os.path.join(ADDONS,   'packages') 

#################
##### INTRO #####
#################

# def INTRO():
    # xbmc.executebuiltin( "PlayMedia(special://home/addons/program.kobra.app.installer/resources/intro/Groundbreaking HD.mp4)" )
    # xbmc.sleep(6000)
    # INDEX1()


#################
#### INDEX 1 ####
#################

def INDEX1():
    if xbmc.getCondVisibility("System.Platform.Android"):
       addDir('[COLOR lime]ANDROID[/COLOR]',BASEURL,2,ART+'android3.png',FANART,'')
    if xbmc.getCondVisibility("System.Platform.Windows"):   
       addDir('[COLOR dodgerblue]WINDOWS[/COLOR]',BASEURL,12,ART1+'windows3.png',FANART1,'')
    if xbmc.getCondVisibility("System.Platform.Linux"):
       addDir('[COLOR orange]LINUX[/COLOR]',BASEURL,97,ART2+'linux3.png',FANART2,'')
    addDir('[COLOR lime]REQUESTS[/COLOR]',BASEURL,13,ART+'requests.png',FANART3,'')
    setView('files', 'LIST')


######################
#### ANDROID MENU ####
######################

def BUILDMENU():
    addDir('[COLOR ghostwhite]APPS[/COLOR]',BASEURL,6,ART+'apps.png',FANART,'')
    addDir('[COLOR ghostwhite]CUSTOM KODI/SPMC FORKS[/COLOR]',BASEURL,14,ART+'apps.png',FANART,'')
    addDir('[COLOR ghostwhite]EMULATORS[/COLOR]',BASEURL,7,ART+'emulators.png',FANART,'')
    addDir('[COLOR ghostwhite]ROMS[/COLOR]',BASEURL,15,ART+'roms.png',FANART,'')
    addDir('[COLOR ghostwhite]ADULT APPS[/COLOR]',BASEURL,9,ART+'adult.png',FANART,'')
    setView('files', 'MAIN')
	
# NEXT UPDATE #
#def BUILDMENU():
   # addDir('APPLICATIONS',BASEURL,6,ART+'applications3.png',FANART,'')
   # addDir('EMULATORS',BASEURL,7,ART+'emulators3.png',FANART,'')
   # addDir('ROMS',BASEURL,99,ART+'roms3.png',FANART,'')
   # addDir('MOVIES, TV & SPORT',BASEURL,99,ART+'moviestvandsport3.png',FANART,'')
   # addDir('MUSIC',BASEURL,99,ART+'music3.png',FANART,'')
   # addDir('GAMES',BASEURL,99,ART+'games3.png',FANART,'')
   # addDir('ADULT APPS',BASEURL,9,ART+'adult3.png',FANART,'')
    #setView('files', 'MAIN')

	
######################
#### WINDOWS MENU ####
######################
		
def BUILDMENU1():
    addDir('[COLOR dodgerblue]PROGRAMS[/COLOR]',BASEURL,98,ART1+'programs.png',FANART,'')
    addDir('[COLOR dodgerblue]ISOs[/COLOR]',BASEURL,98,ART1+'isos.png',FANART,'')
    setView('files', 'MAIN')
	
		
################
### APPS URL ###
################

def APPSWIZARD():
    link = OPEN_URL('http://kobracustombuilds.com/apks/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,5,iconimage,fanart,description)
    link2 = OPEN_URL('http://dabutcher.org/tools/apkwizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link2)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,5,iconimage,fanart,description)
    setView('files', 'MAIN')
	
	
######################
### ADULT APPS URL ###
######################

def APPSWIZARD1():
    link = OPEN_URL('http://kobracustombuilds.com/adult/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,10,iconimage,fanart,description)
    link2 = OPEN_URL('http://dabutcher.org/tools/adultapkwizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link2)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,10,iconimage,fanart,description)
    setView('files', 'MAIN')

    
#######################
### CUSTOM APPS URL ###
#######################

def APPSWIZARD2():
    link = OPEN_URL('http://kobracustombuilds.com/apks/wizard/customapkswizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,5,iconimage,fanart,description)
    setView('files', 'MAIN')
	
#####################
### EMULATORS URL ###
#####################

def EMULATORWIZARD():
    link = OPEN_URL('http://kobracustombuilds.com/emulators/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,8,iconimage,fanart,description)
    link2 = OPEN_URL('http://dabutcher.org/tools/emulatorapkwizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link2)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,8,iconimage,fanart,description)
    setView('files', 'MAIN')
	
#####################
### EMULATORS URL ###
#####################

def ROMSWIZARD():
    link = OPEN_URL('http://kobracustombuilds.com/roms/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,16,iconimage,fanart,description)
    link2 = OPEN_URL('http://dabutcher.org/tools/romswizard.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link2)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,16,iconimage,fanart,description)
    setView('files', 'MAIN')
	

#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()   
    
  
############################
#### APPS INSTALL ##########
############################
# THANKS TO ][NT3L][G3NC][ #
############################

def APPINSTALL(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno(name,description,"","","GO BACK","DOWNLOAD"):
    downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("[COLOR lime][B][I]KOBRA[/I][/B][/COLOR][COLOR ghostwhite] [B]APP INSTALLER[/B][/COLOR]","DOWNLOADING...",name,'PLEASE WAIT...')
    lib=os.path.join(downloadpath, name+'.apk')
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    dp.close()
    dialog = xbmcgui.Dialog()
    dialog.ok("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] APP INSTALLER[/B][/COLOR]","DOWNLOAD COMPLETE.","","CLICK OK TO INSTALL " + name + "")
	#][NT3L]I[G3NC][# 
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
    time.sleep(4)
    CLEANUP()
    dialog.ok("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] APP INSTALLER[/B][/COLOR]"," "," ","THANKS FOR USING [COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite] APP INSTALLER[/COLOR]")
    try: os.remove(lib)
    except: pass


#########################
### EMULATOR INSTALL ####
#########################

def EMULATORINSTALL(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno(name,description,"","","GO BACK","DOWNLOAD"):
    downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))#
    dp = xbmcgui.DialogProgress()
    dp.create("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] EMULATOR INSTALLER[/B][/COLOR]","DOWNLOADING...",name,'PLEASE WAIT...')
    lib=os.path.join(downloadpath, name+'.apk')
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    dp.close()
    dialog = xbmcgui.Dialog()
    dialog.ok("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] EMULATOR INSTALLER[/B][/COLOR]","DOWNLOAD COMPLETE.","","CLICK OK TO INSTALL " + name + "")
	#][NT3L]I[G3NC][# 
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
    time.sleep(4)
    CLEANUP()
    dialog.ok("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] EMULATOR INSTALLER[/B][/COLOR]"," "," ","THANKS FOR USING [COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite] APP INSTALLER[/COLOR]")
    try: os.remove(lib)
    except: pass


############################
#### ROMS INSTALL ##########
############################

def ROMINSTALL(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno(name,description,"","","GO BACK","DOWNLOAD"):
    downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("[COLOR lime][B][I]KOBRA[/I][/B][/COLOR][COLOR ghostwhite] [B]ROM INSTALLER[/B][/COLOR]","DOWNLOADING...",name,'PLEASE WAIT...')
    lib=os.path.join(downloadpath, name+'.apk')
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    dp.close()
    dialog = xbmcgui.Dialog()
    dialog.ok("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] ROM INSTALLER[/B][/COLOR]","DOWNLOAD COMPLETE.","","CLICK OK TO INSTALL " + name + "")
	#][NT3L]I[G3NC][# 
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
    time.sleep(4)
    CLEANUP()
    dialog.ok("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] ROM INSTALLER[/B][/COLOR]"," "," ","THANKS FOR USING [COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite] ROM INSTALLER[/COLOR]")
    try: os.remove(lib)
    except: pass
##########################
### ADULT APP INSTALL ####
##########################

def ADULTINSTALL(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno(name,description,"","","GO BACK","DOWNLOAD"):
    downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))#
    dp = xbmcgui.DialogProgress()
    dp.create("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] ADULT APP INSTALLER[/B][/COLOR]","DOWNLOADING...",name,'PLEASE WAIT...')
    lib=os.path.join(downloadpath, name+'.apk')
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    dp.close()
    dialog = xbmcgui.Dialog()
    dialog.ok("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] ADULT APP INSTALLER[/B][/COLOR]","DOWNLOAD COMPLETE.","","CLICK OK TO INSTALL " + name + "")
	#][NT3L]I[G3NC][# 
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
    time.sleep(4)
    CLEANUP()
    dialog.ok("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] ADULT APP INSTALLER[/B][/COLOR]"," "," ","THANKS FOR USING [COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite] ADULT APP INSTALLER[/COLOR]")
    try: os.remove(lib)
    except: pass
	
################################
###### CLEAN UP PACKAGES #######
##### THANKS GUYS @ XUNITY ##### 
##### MODDED BY AFTERMATH ######
################################
		
def CLEANUP():
	if os.path.exists(PACKAGES):
		try:	
			for root, dirs, files in os.walk(PACKAGES):
				file_count = 0
				file_count += len(files)
				# Count files and give option to delete
				if file_count > 0:
					if dialog.yesno("[COLOR lime][B][I]KOBRA[/I][/B][/COLOR][COLOR ghostwhite] [B]FILE CLEANER[/B][/COLOR]", str(file_count) + " FILES FOUND","","WOULD YOU LIKE TO DELETE THE PACKAGE FILES?", nolabel='NO, CANCEL',yeslabel='YES, DELETE'):
						for f in files:	os.unlink(os.path.join(root, f))
						for d in dirs: shutil.rmtree(os.path.join(root, d))
						dialog.ok(AddonTitle3,'[CR][CR]CLEAN UP FILES: [COLOR lime] SUCCESS[/COLOR]!')
				else: dialog.ok(AddonTitle3,'[CR][CR]CLEAN UP FILES: [COLOR red]NONE FOUND[/COLOR]!')
		except: dialog.ok(AddonTitle3,'[CR][CR]CLEAN UP FILES: [COLOR red] ERROR[/COLOR]!')
	else: dialog.ok(AddonTitle3,'[CR][CR]CLEAN UP FILES: [COLOR red] NONE FOUND[/COLOR]!')
	
	
################
### REQUESTS ###
################

def REQUESTS():
    dialog.ok("[COLOR lime][B][I]KOBRA[/I][/COLOR][COLOR ghostwhite] APP INSTALLER[/B][/COLOR]","[COLOR ghostwhite]PLEASE SEND ANY PACKAGE REQUESTS TO:[/COLOR]","[COLOR dodgerblue]FACEBOOK: https://www.facebook.com/groups/KodiCustomBuilds/ [/COLOR]","[COLOR dodgerblue]FACEBOOK: https://www.facebook.com/profile.php?id=100011845114961[/COLOR]")

   
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link


###################
### COMING SOON ###
###################
	
def COMINGSOONWINDOWS():
    addDir('[COLOR dodgerblue]COMING SOON...[/COLOR]','noop',0,ART1+'comingsoon4.png',FANART1,'')
    setView('movies', 'MAIN')
	
def COMINGSOONANDROID():
    addDir('[COLOR lime]COMING SOON...[/COLOR]','noop',0,ART+'comingsoon3.png',FANART,'')
    setView('movies', 'MAIN')

def COMINGSOONLINUX():
    addDir('[COLOR orange]COMING SOON...[/COLOR]','noop',0,ART2+'comingsoon5.png',FANART2,'')
    setView('movies', 'MAIN')

  
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 or mode==8  or mode==10 or mode==11 or mode==13 or mode==16 or url=='noop':
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        X("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None :INDEX1()

elif mode==2:
        BUILDMENU()
		
elif mode==5:
        APPINSTALL(name,url,description)
		
elif mode==6:
        APPSWIZARD()
		
elif mode==7:
        EMULATORWIZARD()

elif mode==8:
        EMULATORINSTALL(name,url,description)
		
elif mode==9:
        APPSWIZARD1()

elif mode==10:
        ADULTINSTALL(name,url,description)
		
elif mode==12:
        BUILDMENU1()
		
elif mode==13:
        REQUESTS()

elif mode==14:
        APPSWIZARD2()

# elif mode==14:
        # INTRO()	

elif mode==15:
		ROMSWIZARD()

elif mode==16:
		ROMINSTALL(name,url,description)

elif mode==97:
        COMINGSOONLINUX()
		
elif mode==98:
        COMINGSOONWINDOWS()
		
elif mode==99:
        COMINGSOONANDROID()


        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
