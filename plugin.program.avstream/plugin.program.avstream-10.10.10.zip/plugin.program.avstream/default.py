################################################################################
#                                                                              #
#      Copyright (C) 2017 Kobra                                                #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
#      Thanks to Surfacingx, ][NT3L][G3NC][, WHUFCLEE, Midraal, OpenELEQ       #
#                                                                              #
################################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import time

from resources.libs import extract, plugintools, downloader


X					= xbmc.executebuiltin
USER_AGENT			= 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id 			= 'plugin.program.avstream'
ADDON 				= xbmcaddon.Addon(id=addon_id)
AddonID				='plugin.video.avstream'
AddonTitle			="Kobra XXX Stream"
dialog  			=  xbmcgui.Dialog()
U					= ADDON.getSetting('User')
FANART 				= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON 				= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART 				= xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION 			= "0.0.1"
DBPATH 				= xbmc.translatePath('special://database')
TNPATH 				= xbmc.translatePath('special://thumbnails');
BASEURL				= "http://kobracustombuilds.com/adult/build/"
EXCLUDES			= ['plugin.video.avstream','repository.kobra']
PATH 				= "Kobra XXX Stream"

def INDEX():
    addDir('KOBRA XXX STREAM',BASEURL,2,ART+'install.png',FANART,'')
    addDir('SETTINGS',BASEURL,10,ART+'settings.png',FANART,'')
    addDir('MAINTENANCE',BASEURL,3,ART+'maintenance.png',FANART,'')
    addDir('CONTACT',BASEURL,8,ART+'facebook.png',FANART,'')
    if ADDON.getSetting('devmode') =="true" : addDir('TEST AREA. PLEASE DO NOT USE',BASEURL+'test.zip',5,ART+'test.png',FANART,'')
    setView('movies', 'MAIN')

def BUILDMENU():
	addDir('INSTALL KOBRA XXX STREAM',BASEURL+'adult.zip',5,ART+'install.png',FANART,'')
	addDir('MINOR UPDATE (ONLY USE IF AUTO UPDATE FAILS)',BASEURL+'adultupdateminor.zip',12,ART+'minorupdate.png',FANART,'')
	addDir('MAJOR UPDATE (ONLY USE IF AUTO UPDATE FAILS)',BASEURL+'adultupdatemajor.zip',5,ART+'majorupdate.png',FANART,'')
	setView('movies', 'MAIN')



def MAINTENANCE():
	addDir('DELETE CACHE','url',4,ART+'deletecache.png',FANART,'')
	addDir('FRESH START','url',6,ART+'freshstart.jpg',FANART,'')
	addDir('DELETE PACKAGES','url',7,ART+'deletepackages.jpg',FANART,'')
	setView('movies', 'MAIN')


#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
	WINDOW=10147
	CONTROL_LABEL=1
	CONTROL_TEXTBOX=5
	def __init__(self,*args,**kwargs):
	  xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
	  self.win=xbmcgui.Window(self.WINDOW) # get window
	  xbmc.sleep(500) # give window time to initialize
	  self.setControls()
	def setControls(self):
	  self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
	  try: f=open(announce); text=f.read()
	  except: text=announce
	  self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
	  return
  TextBox()

  
###############
### CONTACT ###
###############

def facebook():
    X("RunAddon(plugin.program.kobraXXXStreams.notifications)")


################
### SETTINGS ###
################

def OPEN_SETTINGS():
    ADDON.openSettings()


def checkURL(url):
	try:
		response = urllib2.urlopen(url)
		code = response.getcode()
		return True
	except urllib2.HTTPError as e:
		return False

#################################
####BUILD INSTALL################
#################################

def WIZARD(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno("[COLOR red]KOBRA XXX STREAM[/COLOR]",name,"YOU MUST BE 18 OR OVER TO ACCESS THIS ANDROID APPLICATION! BEFORE PROCEEDING YOU MUST READ AND AGREE TO THE TERMS BELOW. THE MATERIALS AVAILABLE WITHIN THIS APPLICATION INCLUDE GRAPHIC VISUAL DEPICTIONS AND DESCRIPTIONS OF NUDITY AND SEXUAL ACTIVITY. BY CLICKING I AGREE BELOW, YOU ARE AGREEING TO THE FOLLOWING: 1. YOU ARE AN ADULT, AT LEAST 18 YEARS OF AGE, YOU ARE FAMILIAR WITH AND UNDERSTAND THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY REGARDING SEXUALLY-ORIENTED MEDIA. YOU REPRESENT THAT, BASED ON YOUR FAMILIARITY WITH THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY, YOU WILL NOT BE VIOLATING ANY APPLICABLE STANDARDS OR LAWS BY REQUESTING, RECEIVING, DOWNLOADING OR POSSESSING ANY OF THE VIDEO, AUDIO, GRAPHICS, IMAGES OR TEXT ADULT MATERIAL AVAILABLE ON THIS APPLICATION. 2. YOU HEREBY ACKNOWLEDGE THAT ANY USE OF THIS APPLICATION IS AT YOUR SOLE RISK. YOU UNDERSTAND THAT BY ACCEPTING THE TERMS OF THIS AGREEMENT, YOU ARE AGREEING TO HOLD THE PUBLISHER OF THIS APPLICATION HARMLESS FROM ANY RESPONSIBILITIES OR LIABILITIES RELATED TO YOUR USE OF THIS APPLICATION AND THE ADULT MATERIAL CONTAINED HEREIN. 3. YOU WILL NOT PERMIT ANY PERSON(S) UNDER 18 YEARS OF AGE TO HAVE ACCESS TO ANY OF THE ADULT MATERIALS CONTAINED IN THIS APPLICATION. 4. YOU ARE VOLUNTARILY CHOOSING TO ACCESS THIS APPLICATION, BECAUSE YOU WANT TO VIEW, READ OR HEAR THE VARIOUS ADULT MATERIALS THAT ARE AVAILABLE. YOU AGREE TO IMMEDIATELY EXIT FROM THIS APPLICATION IF YOU ARE IN ANY WAY OFFENDED BY THE SEXUAL NATURE OF ANY ADULT MATERIAL. 5. IF YOU USE THIS APPLICATION IN VIOLATION OF THESE TERMS, OR USE THIS APPLICATION WHERE SUCH USE IS ILLEGAL, YOU MAY BE IN VIOLATION OF LOCAL AND/OR FEDERAL LAWS. YOU AGREE THAT YOU ARE SOLELY RESPONSIBLE FOR YOUR USE OF THIS APPLICATION AND ANY LINKED THIRD PARTY WEB SITES, AND AGREE TO INDEMNIFY PUBLISHER AGAINST ANY CLAIMS ARISING OUT OF SUCH USE. 6. BY CLICKING I AGREE AT THE BOTTOM OF THIS WINDOW OR BY ENTERING THE APPLICATION, YOU AGREE TO ABIDE BY THE COMPLETE TERMS AND CONDITIONS OF USE OF THIS APPLICATION. IF YOU DO NOT AGREE TO THE COMPLETE TERMS AND CONDITIONS OF USE, CLICK ON THE I DISAGREE BUTTON AND EXIT THE APPLICATION.","","[COLOR orange]I DISAGREE, QUIT[/COLOR]","[COLOR lime]I AGREE, INSTALL[/COLOR]"):
	path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
	dp = xbmcgui.DialogProgress()
	lib=os.path.join(path, name+'.zip')
	dp.create("[COLOR red]KOBRA XXX STREAM[/COLOR]"," ",'', " ")
	lib=os.path.join(path, name+'.zip')
	try:
	   os.remove(lib)
	except:
	   pass
	downloader.download(url, lib, dp)
	addonfolder = xbmc.translatePath(os.path.join('special://','home'))
	time.sleep(2)
	dp.update(0,"", "[COLOR dodgerblue]INSTALLING KOBRA XXX STREAM PLEASE WAIT...[/COLOR]")
	print '======================================='
	print addonfolder
	print '======================================='
	extract.all(lib,addonfolder,dp)
	dp.close()
	dialog = xbmcgui.Dialog()
	dialog.ok("[COLOR red]KOBRA XXX STREAM[/COLOR]", "[COLOR lime][CR]WE NOW NEED TO FORCE STOP KOBRA XXX STREAM FOR THE CHANGES TO BE APPLIED. PLEASE RESTART THE APPLICATION.  PRESS OK TO CONTINUE[/COLOR]")
	os._exit(1)


#################################
####BUILD INSTALL################
#################################

def MINOR_UPDATE_WIZARD(name,url,description):
   confirm=xbmcgui.Dialog()
   if confirm.yesno("[COLOR red]KOBRA XXX STREAM[/COLOR]",name,"YOU MUST BE 18 OR OVER TO ACCESS THIS ANDROID APPLICATION! BEFORE PROCEEDING YOU MUST READ AND AGREE TO THE TERMS BELOW. THE MATERIALS AVAILABLE WITHIN THIS APPLICATION INCLUDE GRAPHIC VISUAL DEPICTIONS AND DESCRIPTIONS OF NUDITY AND SEXUAL ACTIVITY. BY CLICKING I AGREE BELOW, YOU ARE AGREEING TO THE FOLLOWING: 1. YOU ARE AN ADULT, AT LEAST 18 YEARS OF AGE, YOU ARE FAMILIAR WITH AND UNDERSTAND THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY REGARDING SEXUALLY-ORIENTED MEDIA. YOU REPRESENT THAT, BASED ON YOUR FAMILIARITY WITH THE STANDARDS AND LAWS OF YOUR LOCAL COMMUNITY, YOU WILL NOT BE VIOLATING ANY APPLICABLE STANDARDS OR LAWS BY REQUESTING, RECEIVING, DOWNLOADING OR POSSESSING ANY OF THE VIDEO, AUDIO, GRAPHICS, IMAGES OR TEXT ADULT MATERIAL AVAILABLE ON THIS APPLICATION. 2. YOU HEREBY ACKNOWLEDGE THAT ANY USE OF THIS APPLICATION IS AT YOUR SOLE RISK. YOU UNDERSTAND THAT BY ACCEPTING THE TERMS OF THIS AGREEMENT, YOU ARE AGREEING TO HOLD THE PUBLISHER OF THIS APPLICATION HARMLESS FROM ANY RESPONSIBILITIES OR LIABILITIES RELATED TO YOUR USE OF THIS APPLICATION AND THE ADULT MATERIAL CONTAINED HEREIN. 3. YOU WILL NOT PERMIT ANY PERSON(S) UNDER 18 YEARS OF AGE TO HAVE ACCESS TO ANY OF THE ADULT MATERIALS CONTAINED IN THIS APPLICATION. 4. YOU ARE VOLUNTARILY CHOOSING TO ACCESS THIS APPLICATION, BECAUSE YOU WANT TO VIEW, READ OR HEAR THE VARIOUS ADULT MATERIALS THAT ARE AVAILABLE. YOU AGREE TO IMMEDIATELY EXIT FROM THIS APPLICATION IF YOU ARE IN ANY WAY OFFENDED BY THE SEXUAL NATURE OF ANY ADULT MATERIAL. 5. IF YOU USE THIS APPLICATION IN VIOLATION OF THESE TERMS, OR USE THIS APPLICATION WHERE SUCH USE IS ILLEGAL, YOU MAY BE IN VIOLATION OF LOCAL AND/OR FEDERAL LAWS. YOU AGREE THAT YOU ARE SOLELY RESPONSIBLE FOR YOUR USE OF THIS APPLICATION AND ANY LINKED THIRD PARTY WEB SITES, AND AGREE TO INDEMNIFY PUBLISHER AGAINST ANY CLAIMS ARISING OUT OF SUCH USE. 6. BY CLICKING I AGREE AT THE BOTTOM OF THIS WINDOW OR BY ENTERING THE APPLICATION, YOU AGREE TO ABIDE BY THE COMPLETE TERMS AND CONDITIONS OF USE OF THIS APPLICATION. IF YOU DO NOT AGREE TO THE COMPLETE TERMS AND CONDITIONS OF USE, CLICK ON THE I DISAGREE BUTTON AND EXIT THE APPLICATION.","","[COLOR orange]I DISAGREE, QUIT[/COLOR]","[COLOR lime]I AGREE, INSTALL[/COLOR]"):
	path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
	dp = xbmcgui.DialogProgress()
	lib=os.path.join(path, name+'.zip')
	dp.create("[COLOR red]KOBRA XXX STREAM[/COLOR]"," ",'', " ")
	lib=os.path.join(path, name+'.zip')
	try:
	   os.remove(lib)
	except:
	   pass
	downloader.download(url, lib, dp)
	addonfolder = xbmc.translatePath(os.path.join('special://','home'))
	time.sleep(2)
	dp.update(0,"", "[COLOR dodgerblue]INSTALLING UPDATE PLEASE WAIT...[/COLOR]")
	print '======================================='
	print addonfolder
	print '======================================='
	extract.all(lib,addonfolder,dp)
	dp.close()
	dialog = xbmcgui.Dialog()
	dialog.ok("[COLOR red]KOBRA XXX STREAM[/COLOR]", "[COLOR lime][CR]WE NOW NEED TO RELOAD THE SKIN TO APPLY THE CHANGES. PRESS OK TO CONTINUE[/COLOR]")
	X('ReloadSkin()')




################################
###DELETE PACKAGES##############
####THANKS GUYS @ XUNITY########

def DeletePackages(url):
	print '############################################################       DELETING PACKAGES             ###############################################################'
	packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
	try:
		for root, dirs, files in os.walk(packages_cache_path):
			file_count = 0
			file_count += len(files)

		# Count files and give option to delete
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):

					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
					dialog = xbmcgui.Dialog()
					dialog.ok("Kobra XXX stream", "Packages Successfuly Removed", "[COLOR yellow]Brought To You By KobraXXXstream[/COLOR]")
	except:
		dialog = xbmcgui.Dialog()
		dialog.ok("Kobra XXX stream", "Sorry we were not able to remove Package Files", "[COLOR yellow]Brought To You By Kobra XXX stream[/COLOR]")



#################################
###DELETE CACHE##################
####THANKS GUYS @ XUNITY########

def deletecachefiles(url):
	print '############################################################       DELETING STANDARD CACHE             ###############################################################'
	xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
	if os.path.exists(xbmc_cache_path)==True:
		for root, dirs, files in os.walk(xbmc_cache_path):
			file_count = 0
			file_count += len(files)

		# Count files and give option to delete
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?"):

					for f in files:
						try:
							os.unlink(os.path.join(root, f))
						except:
							pass
					for d in dirs:
						try:
							shutil.rmtree(os.path.join(root, d))
						except:
							pass

			else:
				pass
	if xbmc.getCondVisibility('system.platform.ATV2'):
		atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')

		for root, dirs, files in os.walk(atv2_cache_a):
			file_count = 0
			file_count += len(files)

			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):

					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))

			else:
				pass
		atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')

		for root, dirs, files in os.walk(atv2_cache_b):
			file_count = 0
			file_count += len(files)

			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):

					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))

			else:
				pass
			  # Set path to Cydia Archives cache files


	# Set path to What th Furk cache files
	wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
	if os.path.exists(wtf_cache_path)==True:
		for root, dirs, files in os.walk(wtf_cache_path):
			file_count = 0
			file_count += len(files)

		# Count files and give option to delete
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):

					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))

			else:
				pass

				# Set path to 4oD cache files
	channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
	if os.path.exists(channel4_cache_path)==True:
		for root, dirs, files in os.walk(channel4_cache_path):
			file_count = 0
			file_count += len(files)

		# Count files and give option to delete
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?"):

					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))

			else:
				pass

				# Set path to BBC iPlayer cache files
	iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
	if os.path.exists(iplayer_cache_path)==True:
		for root, dirs, files in os.walk(iplayer_cache_path):
			file_count = 0
			file_count += len(files)

		# Count files and give option to delete
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?"):

					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))

			else:
				pass


				# Set path to Simple Downloader cache files
	downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
	if os.path.exists(downloader_cache_path)==True:
		for root, dirs, files in os.walk(downloader_cache_path):
			file_count = 0
			file_count += len(files)

		# Count files and give option to delete
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):

					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))

			else:
				pass

				# Set path to ITV cache files
	itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
	if os.path.exists(itv_cache_path)==True:
		for root, dirs, files in os.walk(itv_cache_path):
			file_count = 0
			file_count += len(files)

		# Count files and give option to delete
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?"):

					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))

			else:
				pass

				# Set path to temp cache files
	temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
	if os.path.exists(temp_cache_path)==True:
		for root, dirs, files in os.walk(temp_cache_path):
			file_count = 0
			file_count += len(files)

		# Count files and give option to delete
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?"):

					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))

			else:
				pass


	dialog = xbmcgui.Dialog()
	dialog.ok("YourCompanyName Wizard", " All Cache Files Removed", "[COLOR yellow]Brought To You By KobraXXXstream[/COLOR]")


def OPEN_URL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
#######LEE @ COMMUNITY BUILDS##################################

def killxbmc():
	myplatform = platform()
	print "Platform: " + str(myplatform)
	if myplatform == 'osx': # OSX
		print "############   try osx force close  #################"
		try: os.system('killall -9 XBMC')
		except: pass
		try: os.system('killall -9 Kodi')
		except: pass
		dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'linux': #Linux
		print "############   try linux force close  #################"
		try: os.system('killall XBMC')
		except: pass
		try: os.system('killall Kodi')
		except: pass
		try: os.system('killall -9 xbmc.bin')
		except: pass
		try: os.system('killall -9 kodi.bin')
		except: pass
		dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'android': # Android
		print "############   try android force close  #################"
		try: os._exit(1)
		except: pass
		dialog.ok("[COLOR=yellow][B]You're Almost There[/COLOR][/B]", "Press the HOME key on your device/remote, Settings > Apps > Kobra XXX Stream > Force Stop then launch Kobra XXX")
	elif myplatform == 'windows': # Windows
		print "############   try windows force close  #################"
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except: pass
		dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
	else: #ATV
		print "############   try atv force close  #################"
		try: os.system('killall AppleTV')
		except: pass
		print "############   try raspbmc force close  #################" #OSMC / Raspbmc
		try: os.system('sudo initctl stop kodi')
		except: pass
		try: os.system('sudo initctl stop xbmc')
		except: pass
		dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")

##########################
###DETERMINE PLATFORM#####
##########################

def platform():
	if xbmc.getCondVisibility('system.platform.android'):
		return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):
		return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'ios'

############################
###FRESH START##############
####THANKS TO TVADDONS######

def FRESHSTART(params):
	plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Do you wish to restore your","configuration to default settings?")
	if yes_pressed:
		addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath);
		xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
		try:
			for root, dirs, files in os.walk(xbmcPath,topdown=True):
				dirs[:] = [d for d in dirs if d not in EXCLUDES]
				for name in files:
					try: os.remove(os.path.join(root,name))
					except:
						if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
						plugintools.log("Error removing "+root+" "+name)
				for name in dirs:
					try: os.rmdir(os.path.join(root,name))
					except:
						if name not in ["Database","userdata"]: failed=True
						plugintools.log("Error removing "+root+" "+name)
			if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(AddonTitle,"The process is complete, you're now back to a fresh Kobra XXX Stream configuration with Kobra XXX!","Please reboot your system or restart Kobra XXX Stream in order for the changes to be applied.")
			else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"The process is complete, you're now back to a fresh Kobra XXX Stream configuration with Kobra XXX Stream","Please reboot your system or restart Kobra XXX in order for the changes to be applied.")
		except: plugintools.message(AddonTitle,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
		plugintools.add_item(action="",title="Now Exit The Media Center",folder=False)
	else: plugintools.message(AddonTitle,"Your settings","has not been changed"); plugintools.add_item(action="",title="Done",folder=False)



def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]

		return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
		liz.setProperty( "Fanart_Image", fanart )
		if mode==5 or mode==8 or mode==10 or mode==12:
			ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		else:
			ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok



params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		iconimage=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass
try:
		fanart=urllib.unquote_plus(params["fanart"])
except:
		pass
try:
		description=urllib.unquote_plus(params["description"])
except:
		pass


print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view')=='true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )


if mode==None or url==None or len(url)<1:
		INDEX()

elif mode==2:
		BUILDMENU()

elif mode==3:
		MAINTENANCE()

elif mode==4:
		deletecachefiles(url)

elif mode==5:
		WIZARD(name,url,description)

elif mode==6:
	FRESHSTART(params)

elif mode==7:
	   DeletePackages(url)

elif mode==8:
	   facebook()

elif mode==9:
	   donation()

elif mode==10:
		OPEN_SETTINGS()

elif mode==11:
		DELETEIVUEDB()

elif mode==12:
		MINOR_UPDATE_WIZARD(name,url,description)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
