################################################################################
#                                                                              #
#      Copyright (C) 2017 Kobra                                                #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
#      Thanks to Surfacingx, ][NT3L][G3NC][, WHUFCLEE, Midraal, OpenELEQ       #
#                                                                              #
################################################################################


import os 
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import shutil
import platform
import subprocess
import urllib
import urllib2
import re

from resources.libs import downloader, extract, vfs
from resources.libs.vfs import VFSClass


ADDON_ID	= 'plugin.program.avstream'
ADDON		= xbmcaddon.Addon(ADDON_ID)
DIALOG		= xbmcgui.Dialog()
DP			= xbmcgui.DialogProgress()
HOME		= xbmc.translatePath('special://home/')
ADDONS		= os.path.join(HOME, 'addons')
PACKAGES	= os.path.join(ADDONS, 'packages')
URL			= 'http://kobracustombuilds.com/adult/wizard/adultupdateminor.txt'
URL2		= 'http://kobracustombuilds.com/adult/wizard/adultupdatemajor.txt'
USER_AGENT	= 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'
DISABLE		= ADDON.getSetting('disableminorupdate')
DISABLE2	= ADDON.getSetting('disablemajorupdate')
DISABLE3	= ADDON.getSetting('cleartemponstart')
INSTALLED	= ADDON.getSetting('installed')
INSTALLED2	= ADDON.getSetting('installed2')


def openURL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def doUpdate(version, url):
		DP.create('[COLOR lime][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[CR][COLOR dodgerblue]DOWNLOADING UPDATE[/COLOR]','', '[COLOR dodgerblue]PLEASE WAIT[/COLOR]')
		lib=os.path.join(PACKAGES, 'adultupdateminor.zip')
		try: os.remove(lib)
		except: pass
		downloader.download(url, lib, DP)
		time.sleep(2)
		DP.update(0,'','INSTALLING UPDATE')
		time.sleep(2)
		extract.all(lib, HOME, DP)
		DP.close()
		DIALOG.ok('[COLOR lime][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[CR][COLOR dodgerblue]UPDATE[/COLOR] [COLOR lime]SUCCESSFUL[/COLOR]','[CR][COLOR dodgerblue]CLICK [COLOR ghostwhite][B]OK[/B][/COLOR] TO APPLY THE UPDATE[/COLOR]')
		ADDON.setSetting('installed', version)
		xbmc.executebuiltin('ReloadSkin()')


def doUpdate2(version, url):
	if DIALOG.yesno('[COLOR lime][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[COLOR dodgerblue][CR]NEW MAJOR UPDATE AVAILABLE','','WOULD YOU LIKE TO INSTALL THIS UPDATE?[/COLOR]','[COLOR orange]NO, GO BACK[/COLOR]','[COLOR lime]YES, INSTALL[/COLOR]'):
		ADDON.setSetting('installed2', version)
		DP.create('[COLOR lime][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[CR][COLOR dodgerblue]DOWNLOADING UPDATE[/COLOR]','', '[COLOR dodgerblue]PLEASE WAIT[/COLOR]')
		lib=os.path.join(PACKAGES, 'adultupdatemajor.zip')
		try: os.remove(lib)
		except: pass
		downloader.download(url, lib, DP)
		time.sleep(2)
		DP.update(0,'','INSTALLING UPDATE')
		time.sleep(2)
		extract.all(lib, HOME, DP)
		DP.close()
		DIALOG.ok('[COLOR lime][B][I]KOBRA [/I][/B][/COLOR][COLOR ghostwhite] [B]XXX STREAM AUTO UPDATER[/B][/COLOR]','[COLOR dodgerblue]UPDATE[/COLOR] [COLOR lime]SUCCESSFUL[/COLOR]','[COLOR dodgerblue]CLICK [COLOR ghostwhite][B]OK[/B][/COLOR] TO FORCE CLOSE KOBRA XXX STREAM TO APPLY CHANGES THEN PLEASE RESTART THE APPLICATION[/COLOR]')
		xbmc.executebuiltin('ReloadSkin()')
		os._exit(1)


def checkUpdateMinor():
	time.sleep(5)
	link = openURL(URL).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="minor".+?ersion="(.+?)".+?rl="(.+?)"').findall(link)
	if len(match) > 0:
		for version, url in match:
			if version > INSTALLED:
				doUpdate(version, url)
			else: 
				xbmc.log("No new version of minor update avaliable.")
	else:
		xbmc.log("Unable to grab version of minor update.", xbmc.LOGDEBUG)


def checkUpdateMajor():
	time.sleep(5)
	link = openURL(URL2).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('name="major".+?ersion="(.+?)".+?rl="(.+?)"').findall(link)
	if len(match) > 0:
		for version, url in match:
			if version > INSTALLED2:
				doUpdate2(version, url)
			else: 
				xbmc.log("No new version of major update avaliable.")
	else:
		xbmc.log("Unable to grab version of major update.", xbmc.LOGDEBUG)


def cleanup():
	vfs = VFSClass()
	mod = vfs.read_file('special://home/addons/plugin.program.avstream/resources/mod.txt')
	#mod = vfs.read_file('special://xbmc/addons/plugin.video.kobrawizard/resources/mod.txt') # For Use on Builtin Wizard In Android Application
	xbmc.log(mod)
	temp_path = os.path.join(HOME, 'cache')
	excludeThat = 'commoncache.db','kodi.log' #fixed android error
	for root, dirs, files in os.walk(temp_path):
	  if  len(files) > 0:
		for f in files:
		  if not f in excludeThat:
			try: os.unlink(os.path.join(root, f))
			except: pass
		for d in dirs:
		  try: shutil.rmtree(os.path.join(root, d))
		  except: pass	  
	android_temp_path = xbmc.translatePath(os.path.join('special://home/temp', ''))
	for root, dirs, files in os.walk(android_temp_path):
	  if  len(files) > 0:
		for f in files:
		  if not f in excludeThat:
			try: os.unlink(os.path.join(root, f))
			except: pass
		for d in dirs:
		  try: shutil.rmtree(os.path.join(root, d))
		  except: pass
	cache_temp_path = xbmc.translatePath(os.path.join('special://home/cache/temp', ''))
	for root, dirs, files in os.walk(cache_temp_path):
	  if  len(files) > 0:
		for f in files:
		  if not f in excludeThat:
			try: os.unlink(os.path.join(root, f))
			except: pass
		for d in dirs:
		  try: shutil.rmtree(os.path.join(root, d))
		  except: pass


if (__name__ == "__main__"):
	if not DISABLE == 'true':
		checkUpdateMinor()
	if not DISABLE2 == 'true':
		checkUpdateMajor()
	if not DISABLE3 == 'true':
		cleanup()