#      Copyright (C) 2015 whufclee
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import os, re, xbmc, xbmcaddon, xbmcgui
ADDON_ID         = 'plugin.video.kobrawizard'
ADDONTITLE       = 'Kobra XXX Stream'
ADDON            = xbmcaddon.Addon(id=ADDON_ID)
VERSION          = ADDON.getAddonInfo('version')
DIALOG           = xbmcgui.Dialog()
DP               = xbmcgui.DialogProgress()
PATH             = ADDON.getSetting('downloads')
TESTPATH         = xbmc.translatePath(os.path.join(PATH,'testCBFolder'))

def check():
	try:
		os.makedirs(TESTPATH)
		os.removedirs(TESTPATH)
		xbmc.executebuiltin('Dialog.Show(busydialog)')
		DIALOG.ok('[COLOR=lime]SUCCESS[/COLOR]', 'Great news, the path you chose is writeable.', 'Some downloads are rather big, we recommend', 'a minimum of 1GB storage space.')
	except:
		xbmc.executebuiltin('Dialog.Show(busydialog)')
		DIALOG.ok('INVALID PATH', 'Kodi cannot write to the path you\'ve chosen. Please click OK and choose another location. Please note: currently network shares are not supported so we suggest using something like a USB stick.')
	ADDON.openSettings()
	xbmc.executebuiltin('Dialog.Close(busydialog)')
    
if __name__ == '__main__':
    check()