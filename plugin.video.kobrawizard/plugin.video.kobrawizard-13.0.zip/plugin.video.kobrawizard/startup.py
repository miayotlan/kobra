################################################################################
#                                                                              #
#      Copyright (C) 2017 Kobra                                                #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
#      Thanks to Surfacingx, ][NT3L][G3NC][, WHUFCLEE, Midraal, OpenELEQ       #
#                                                                              #
################################################################################


import os 
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import sys
import urllib
import urllib2
import re

from resources.libs import downloader, extract, vfs
from resources.libs.vfs import VFSClass

X               = xbmc.executebuiltin
T               = time.sleep
ADDON_ID        = 'plugin.video.kobrawizard'
ADDON           = xbmcaddon.Addon(ADDON_ID)
DIALOG          = xbmcgui.Dialog()
DP              = xbmcgui.DialogProgress()
HOME            = xbmc.translatePath('special://home/')
ADDONS          = os.path.join(HOME, 'addons')
PACKAGES        = os.path.join(ADDONS, 'packages')
URL             = 'http://kobracustombuilds.com/builds/wizard/minor.txt'
URL2            = 'http://kobracustombuilds.com/builds/wizard/major.txt'
USER_AGENT      = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'
DISABLE         = ADDON.getSetting('disableminorupdate')
DISABLE2        = ADDON.getSetting('disablemajorupdate')
DISABLE3        = ADDON.getSetting('cleartemponstart')
INSTALLED       = ADDON.getSetting('installed')
INSTALLED2      = ADDON.getSetting('installed2')
CHECK_BUILD     = ADDON.getSetting('checkonstart')
NEWFEATURES     = ADDON.getSetting('newfeatures')
CONFIRM         = xbmcgui.Dialog()
ADDON_TITLE3    = "[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] FILE CLEANER[/COLOR]"



def openURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link


def Update_Minor(version, url):
    if DIALOG.yesno('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MINOR UPDATE[/COLOR]','[COLOR ghostwhite][CR]There is a new minor update available[/COLOR]','','[COLOR ghostwhite]Would you like to install this update?[/COLOR]','[COLOR orange]NO, GO BACK[/COLOR]','[COLOR lime]YES, INSTALL[/COLOR]'):
        DP.create('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MINOR UPDATE[/COLOR]','[CR][COLOR ghostwhite]Downloading update, [/COLOR]','','[COLOR ghostwhite]lease wait[/COLOR]')
        lib=os.path.join(PACKAGES, 'minorupdate.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,'','[COLOR ghostwhite]Installing update[/COLOR]')
        T(3)
        extract.all(lib, HOME, DP)
        DP.close()
        try: os.remove(lib)
        except: pass
        ADDON.setSetting('installed', version)
        DIALOG.ok('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MINOR UPDATE[/COLOR]','[CR][COLOR ghostwhite]Update[/COLOR] [COLOR lime]successful[/COLOR]','[CR][COLOR ghostwhite]Click OK to apply the update[/COLOR]')
        X('ReloadSkin()')
        T(1)
        X("XBMC.Container.Update(path,replace)")
        X("XBMC.ActivateWindow(Home)")
        xbmc.log("KOBRA WIZARD AUTO UPDATE CHECK: Minor update successfully completed.")
        T(1)
        X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MINOR UPDATE[/COLOR],[COLOR ghostwhite]Update successfully applied[/COLOR],5000,special://home/addons/plugin.video.kobrawizard/icon.png)')
    else: 
        DIALOG.ok('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MINOR UPDATE[/COLOR]','[CR][COLOR ghostwhite]OK cool, no problem[/COLOR]','[COLOR ghostwhite][CR]You will be prompted again on next boot[/COLOR]')
        xbmc.log("KOBRA WIZARD AUTO UPDATE CHECK: Aborted by user.")


def Update_Major(version, url):
    if DIALOG.yesno('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MAJOR UPDATE[/COLOR]','[COLOR ghostwhite][CR]There is a new major update available[/COLOR]','','[COLOR ghostwhite]Would you like to install this update?[/COLOR]','[COLOR orange]NO, GO BACK[/COLOR]','[COLOR lime]YES, INSTALL[/COLOR]'):
        DP.create('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MAJOR UPDATE[/COLOR]','[CR][COLOR ghostwhite]Downloading update,[/COLOR]','','[COLOR ghostwhite] please wait[/COLOR]')
        lib=os.path.join(PACKAGES, 'minorupdate.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,'','[COLOR ghostwhite]Installing update[/COLOR]')
        T(2)
        extract.all(lib, HOME, DP)
        DP.close()
        ADDON.setSetting('installed2', version)
        try: os.remove(lib)
        except: pass
        DIALOG.ok('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MAJOR UPDATE[/COLOR]','[CR][COLOR ghostwhite]Update[/COLOR] [COLOR lime]successful[/COLOR]','[COLOR ghostwhite]Click OK to quit kobra then restart the application to complete the update[/COLOR]')
        T(1)
        X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MAJOR UPDATE[/COLOR],[COLOR ghostwhite]Smell you later. Bye bye[/COLOR],5000,special://home/addons/plugin.video.kobrawizard/icon.png)')
        xbmc.log("KOBRA WIZARD AUTO UPDATE CHECK: Major update successfully completed.")
        T(6)
        os._exit(1)
    else: 
        DIALOG.ok('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MAJOR UPDATE[/COLOR]','[CR][COLOR ghostwhite]OK cool, no problem[/COLOR]','[COLOR ghostwhite][CR]You will be prompted again on next boot[/COLOR]')
        xbmc.log("KOBRA WIZARD AUTO UPDATE CHECK: Aborted by user.")


def install_kobrah24_build():
    url='http://kobracustombuilds.com/builds/kobrah24nonadult.zip'
    DP.create('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  H24 BUILD INSTALLER[/COLOR]','[CR][COLOR ghostwhite]Downloading build,[/COLOR]','','[COLOR ghostwhite] please wait[/COLOR]')
    lib=os.path.join(PACKAGES, 'kobrah24build.zip')
    try: os.remove(lib)
    except: pass
    downloader.download(url, lib, DP)
    T(2)
    DP.update(0,'','[COLOR ghostwhite]Installing build[/COLOR]')
    T(2)
    extract.all(lib, HOME, DP)
    DP.close()
    ADDON.setSetting('checkonstart', 'false')
    try: os.remove(lib)
    except: pass
    DIALOG.ok('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  H24 BUILD INSTALLER[/COLOR]','[CR][COLOR ghostwhite]Install[/COLOR] [COLOR lime]successful[/COLOR]','[COLOR ghostwhite]Click OK to quit kobra then restart the application to complete the installation[/COLOR]')
    T(1)
    X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  H24 BUILD INSTALLER[/COLOR],[COLOR ghostwhite]Smell you later. Bye bye[/COLOR],5000,special://home/addons/plugin.video.kobrawizard/icon.png)')
    T(6)
    os._exit(1)

def clean_up():
    if os.path.exists(PACKAGES):
        try:
            for root, dirs, files in os.walk(PACKAGES):
                file_count = 0
                file_count += len(files)
                # Count files and give option to delete
                if file_count > 0:
                    if DIALOG.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] FILE CLEANER[/COLOR]"," ", "[COLOR ghostwhite]{0} files found, [CR][CR]Would you like to remove them?[/COLOR]".format(file_count),"","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, REMOVE[/COLOR]"):
                        for f in files: os.unlink(os.path.join(root, f))
                        for d in dirs: shutil.rmtree(os.path.join(root, d))
                        DIALOG.ok(ADDON_TITLE3,'[CR][CR][COLOR ghostwhite]Clean up files:[/COLOR] [COLOR lime] Successful[/COLOR]')
                else: DIALOG.ok(ADDON_TITLE3,'[CR][CR][COLOR ghostwhite]Clean up files:[/COLOR] [COLOR red]No files found[/COLOR]')
        except: DIALOG.ok(ADDON_TITLE3,'[CR][CR][COLOR ghostwhite]Clean up files:[/COLOR] [COLOR red] ! Error ![/COLOR]')
    else: DIALOG.ok(ADDON_TITLE3,'[CR][CR][COLOR ghostwhite]Clean up files:[/COLOR] [COLOR red] NO files found[/COLOR]')

def new_features():
    if xbmcvfs.exists("special://home/addons/skin.aeon.nox.kobra/media/frame2.png"):
        if not NEWFEATURES == 'true':
            DIALOG.ok("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] WIZARD NEW FEATURES[/COLOR]",'[CR][COLOR red]IMPORTANT INFORMATION. PLEASE READ![/COLOR][COLOR ghostwhite][CR][CR]Welcome to the new Kobra Wizard. The new wizard now features auto updates in two parts.[CR][COLOR dodgerblue]Major update:[/COLOR][CR]This update will include major changes to the build that could include skin modifications, background changes and removal or adding new features.[CR][COLOR dodgerblue]Minor update:[/COLOR] [CR]This update will include removal of broken links in the sub menu and adding new menu items.[CR]You will be prompted on startup if there is a new major or minor update available. If you choose not to update, you will be prompted again the next time you start the application. You can also choose to disable the auto update feature but you will no longer receive any update notifications from Kobra Builds. It is reccomended that this feature is enabled.[/COLOR][COLOR red][CR][CR]WARNING[/COLOR]','[COLOR ghostwhite]The Kobra Wizard does contain adult content which is disabled by default. If you would like to enable adult content you can do so via the add-on settings within the main menu. The main Kobra H24 build is no longer contains an adult content profile but I have compensated for this by releasing a standalone adult application that is available for Android and Windows devices. This application can be downloaded via the Kobra Wizard in the Kobra XXX Stream section.[/COLOR]')
            ADDON.setSetting('newfeatures', 'true')
            xbmc.log("KOBRA WIZARD NEW FEATURES MESSAGE: message shown.")
        else: 
            xbmc.log("KOBRA WIZARD NEW FEATURES MESSAGE: message already shown.")
    else: 
        xbmc.log("KOBRA WIZARD NEW FEATURES MESSAGE: No kobra build installed. Skipping message.")

def Check_Update_Minor():
    T(1)
    link = openURL(URL).replace('\n','').replace('\r','').replace('\t','')
    match = re.compile('name="minor".+?ersion="(.+?)".+?rl="(.+?)"').findall(link)
    if len(match) > 0:
        for version, url in match:
            if version > INSTALLED:
                Update_Minor(version, url)
            else: 
                xbmc.log("KOBRA WIZARD AUTO UPDATE CHECK: No new version of minor update avaliable.")
    else:
        xbmc.log("KOBRA WIZARD AUTO UPDATE CHECK: Unable to grab version of minor update.", xbmc.LOGDEBUG)


def Check_Update_Major():
    T(2)
    link = openURL(URL2).replace('\n','').replace('\r','').replace('\t','')
    match = re.compile('name="major".+?ersion="(.+?)".+?rl="(.+?)"').findall(link)
    if len(match) > 0:
        for version, url in match:
            if version > INSTALLED2:
                Update_Major(version, url)
            else: 
                xbmc.log("KOBRA WIZARD AUTO UPDATE CHECK: No new version of major update avaliable.")
    else:
        xbmc.log("KOBRA WIZARD AUTO UPDATE CHECK: Unable to grab version of major update.", xbmc.LOGDEBUG)


def print_log():
    vfs = VFSClass()
    mod = vfs.read_file('special://home/addons/plugin.video.kobrawizard/resources/mod.txt')
    #mod = vfs.read_file('special://xbmc/addons/plugin.video.kobrawizard/resources/mod.txt') # For Use on Builtin Wizard In Android Application
    xbmc.log(mod)
    if not DISABLE == 'true':
        Check_Update_Minor()
    if not DISABLE2 == 'true':
        Check_Update_Major()


if (__name__ == "__main__"):
    if xbmcvfs.exists("special://home/addons/skin.aeon.nox.kobra/media/frame2.png"):
        xbmc.log("KOBRA WIZARD: Kobra build found. Starting auto update service.")
        print_log()      
    else:
        xbmc.log("KOBRA WIZARD: No Kobra build found. Starting auto build install service.")
        if CHECK_BUILD =='true':
            if CONFIRM.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] H24 BUILD INSTALLER[/COLOR]","[CR][COLOR ghostwhite]For use on a fresh installaion of Kodi/Spmc only[/COLOR]","[COLOR ghostwhite]You currently have no Kobra build installed[/COLOR]","[COLOR ghostwhite]Would you like to install Kobra H24 build?[/COLOR]","[COLOR orange]NO THANKS[/COLOR]","[COLOR lime]YES, INSTALL[/COLOR]"):
                install_kobrah24_build()
            else:
                xbmc.log("KOBRA WIZARD AUTO BUILD INSTALL: Aborted by user.")
                if CONFIRM.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] H24 BUILD INSTALLER[/COLOR]"," ","[COLOR ghostwhite] [/COLOR]","[COLOR ghostwhite]Would you like to disable Kobra build auto check on start?[/COLOR]","[COLOR orange]NO[/COLOR]","[COLOR lime]YES[/COLOR]"):
                    DIALOG.ok('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  H24 BUILD INSTALLER[/COLOR]','[CR][COLOR ghostwhite]OK cool, no problem[/COLOR]','[COLOR ghostwhite][CR]Kobra auto build check has been disabled[/COLOR]')
                    ADDON.setSetting('checkonstart', 'false')
                    xbmc.log("KOBRA WIZARD: Auto update service disabled by user.")
                else:
                    xbmc.log("KOBRA WIZARD: Auto update service enabled by user.")
                    DIALOG.ok('[COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  H24 BUILD INSTALLER[/COLOR]','[CR][COLOR ghostwhite]OK cool, no problem[/COLOR]','[COLOR ghostwhite][CR]You will be prompted again on next boot[/COLOR]')
        else:
            xbmc.log("KOBRA WIZARD: Auto update service is disabled.")