################################################################################
#                                                                              #
#                        Copyright (C) 2017 Kobra                              #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
#                                                                              #
################################################################################

################################################################################
#                                                                              #
#      Thanks to Surfacingx, ][NT3L][G3NC][, WHUFCLEE, Midraal, OpenELEQ       #
#             TV-Addons, Xunity and anyone else I may have missed.             #
#                                                                              #
################################################################################


import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import sys
import xbmcvfs
import shutil
import urllib2,urllib
import re, subprocess
import time
#import winsound # testing code finish on windows

from resources.libs import plugintools, downloader, extract, checkPath


X                   = xbmc.executebuiltin
T                   = time.sleep
DIVIDE              = '[COLOR lime]-------------------------------------------------------------------------------------------------------[/COLOR]'
REGEX               = 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"'
HOME                = xbmc.translatePath('special://home/')
ADDONS              = os.path.join(HOME,     'addons')
ADDON_ID            = 'plugin.video.kobrawizard'
ADDON               = xbmcaddon.Addon(id=ADDON_ID)
ADDON_TITLE         = "[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] WIZARD[/COLOR]"
ADDON_TITLE2        = "[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] DELETE PACKAGE FILES[/COLOR]"
ADDON_TITLE3        = "[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] FILE CLEANER[/COLOR]"
DIALOG              = xbmcgui.Dialog()
USERDATA            = os.path.join(HOME,      'userdata')
ADDONDATA           = os.path.join(USERDATA,  'addon_data', ADDON_ID)
WIZLOG              = os.path.join(ADDONDATA, 'wizard.log')
USER                = ADDON.getSetting('User')
FANART              = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
ART                 = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID + '/resources/art/'))
VERSION             = "12.2"
PLUGIN              = os.path.join(ADDONS,    ADDON_ID)
ICON                = os.path.join(PLUGIN,    'icon.png')
DBPATH              = xbmc.translatePath('special://database')
TNPATH              = xbmc.translatePath('special://thumbnails');
PATH                = "Kobra Wizard"
BASEURL             = "http://kodicustombuilds.com/kobracustombuilds.com/builds/"
BASEURL1            = "http://kobracustombuilds.com/adult/build/"
BASEURL2            = "http://kobra24.com/test"
PACKAGES            = os.path.join(ADDONS,   'packages')
EXCLUDES            = ['plugin.video.kobrawizard','script.kobra.builds','plugin.program.kobra.notifications','repository.kobra','plugin.video.kobra.tube','program.kobra.app.installer']
CONFIRM             = xbmcgui.Dialog()
DP                  = xbmcgui.DialogProgress()
ADDON_FOLDER        = xbmc.translatePath(os.path.join('special://','home'))
RETURN              = 'ActivateWindow(10000,return)'
KOBRA               = "[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM INSTALLER[/COLOR]"
KOBRA1              = "[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]WIZARD[/COLOR]"
KOBRA2              = "[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM INSTALLER[/COLOR]"
DOWNLOADPATH        = ADDON.getSetting('downloads')
WINDOWSAPPSPATH     = os.path.join(DOWNLOADPATH, 'KOBRA-XXX-STREAM')
OPENPATH            = os.path.join(WINDOWSAPPSPATH, 'KodiPortable.exe')
ADULT               = ADDON.getSetting('adult')
NEWFEATURES         = ADDON.getSetting('newfeatures')
#START_APP          = os.path.join(WINDOWSAPPSPATH, 'a.bat') # possible future update


#############
### INTRO ###
#############

def intro():
    X( "PlayMedia(special://home/addons/plugin.video.kobrawizard/resources/intro/intro.mp4)" )
    T(5)
    xbmc.executebuiltin('PlayerControl(Stop))')
    main_menu()


####################
### NEW FEATURES ###
####################

# def new_features():
    # if not NEWFEATURES == 'true':
        # DIALOG.ok("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] WIZARD NEW FEATURES[/COLOR]",'[CR][COLOR red]IMPORTANT INFORMATION. PLEASE READ![/COLOR][COLOR ghostwhite][CR][CR]Welcome to the new Kobra Wizard. The new wizard now features auto updates in two parts. Major update, this update will include major changes to the build that could include skin modifications, background changes and removal or adding new features. Minor update could include removal of broken links in the sub menu and adding new menu items.[CR]You will be prompted on startup if there is a new major or minor update available. If you choose not to update, you will be prompted again the next time you start the application. You can also choose to disable the auto update feature but you will no longer receive any update notifications from Kobra Builds. It is reccomended that this feature is enabled. [/COLOR][COLOR red]WARNING[/COLOR]','[COLOR ghostwhite]The Kobra Wizard does contain adult content which is disabled my default. If you would like to enable adult content you can do so via the add-on settings within the main menu.[/COLOR]')
        # ADDON.setSetting('newfeatures', 'true')
        # check_download_path()
    # else: 
        # check_download_path()

def new_features1():
    text_boxes(ADDON_TITLE,"[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] WIZARD NEW FEATURES[/COLOR][CR][COLOR ghostwhite]Welcome to the new Kobra Wizard. The new wizard now features auto updates in two parts.[CR][COLOR dodgerblue]Major update:[/COLOR][CR]This update will include major changes to the build that could include skin modifications, background changes and removal or adding new features.[CR][COLOR dodgerblue]Minor update:[/COLOR] [CR]This update will include removal of broken links in the sub menu and adding new menu items.[CR]You will be prompted on startup if there is a new major or minor update available. If you choose not to update, you will be prompted again the next time you start the application. You can also choose to disable the auto update feature but you will no longer receive any update notifications from Kobra Builds. It is reccomended that this feature is enabled. [/COLOR][COLOR red][CR]WARNING[/COLOR][COLOR ghostwhite][CR]The Kobra Wizard does contain adult content which is disabled by default. If you would like to enable adult content you can do so via the add-on settings within the main menu. The main Kobra H24 build is no longer contains an adult content profile but I have compensated for this by releasing a standalone adult application that is available for Android and Windows devices. This application can be downloaded via the Kobra Wizard in the Kobra XXX Stream section.[/COLOR]")
        
        
###########################
### CHECK DOWNLOAD PATH ###
###########################

def check_download_path():
    if DOWNLOADPATH == '' or not os.path.exists(DOWNLOADPATH):
        if DIALOG.yesno(KOBRA1,'[COLOR ghostwhite][CR]You will need to setup a downloads path to use some sections of the Kobra Wizard. If you choose not to setup a downloads path now, you will be prompted to do so when needed.','Would you like to do this now?[/COLOR]',' ','[COLOR orange]NO, DO IT LATER[/COLOR]','[COLOR lime]YES, SETUP NOW[/COLOR]'):
            settings(ADDON_ID, 4.0, True)
            main_menu()
        else: main_menu()
    else: main_menu()


#################
### MAIN MENU ###
#################

def main_menu():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]WIZARD[/COLOR]','noop',0,ART+'kobrawizard.png',FANART,'')
    if ADULT == 'true': 
        add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    if xbmc.getCondVisibility('system.platform.android'): # Android
        if ADULT == 'true': add_dir('[COLOR ]Kobra XXX Stream Section (Adult only)[/COLOR]',BASEURL,46,ART+'kobraxxx.png',FANART,'')
    if xbmc.getCondVisibility('system.platform.windows'): # Windows
        if ADULT == 'true': add_dir('[COLOR ]Kobra XXX Stream Section (Adult only)[/COLOR]',BASEURL,40,ART+'kobraxxx.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    add_dir('[COLOR ]Kobra H24 Build Section (Non adult)[/COLOR]',BASEURL,2,ART+'kobrah24buildsection.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'template.png')
    add_dir('[COLOR ]Kobra Contact and Information[/COLOR]',BASEURL,8,ART+'contact11.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    add_dir('[COLOR ]Kobra Maintenance Tools[/COLOR]',BASEURL,3,ART+'maintenance11.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    add_dir('[COLOR ]Kobra Preview Videos[/COLOR]',BASEURL,30,ART+'previewvideos11.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    #add_dir('[COLOR ]TWEAKS AND FIXES[/COLOR]',BASEURL,99,ART+'tweaksandfixes11.png',FANART,'') # possible future update
    if xbmc.getCondVisibility('system.platform.android'): add_dir('[COLOR ]Kobra App Installer[/COLOR]',BASEURL,28,ART+'appinstaller11.png',FANART,'')
    if xbmc.getCondVisibility('system.platform.android'): add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    add_dir('[COLOR ]Kobra Settings[/COLOR]',BASEURL,37,ART+'settings1.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    add_dir('[COLOR ]New Features[/COLOR]',BASEURL,51,ART+'newfeatures.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    if ADDON.getSetting('devmode') =="true" : add_dir('Test area',BASEURL+'test.zip',5,ART+'testarea11.png',FANART,'')
    if ADDON.getSetting('devmode') =="true" : add_dir(DIVIDE,'noop',0,ART+'template.png',FANART,'')
    add_dir('[COLOR ]MQ7 Pimped by Paulsk2[/COLOR]',BASEURL,33,ART+'sk21.png',FANART,'')
    set_view('files', 'MAIN')


############################
### KOBRA H24 BUILD MENU ###
############################

def kobra_h24_build_menu():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 INSTALL[/COLOR]','noop',0,ART+'kobrah24install.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'skull_template.png',FANART,'')
    add_dir('Kobra H24 build install and information (Fresh install only)',BASEURL,38,ART+'kobrah24install.png',ART+'bg2.jpg','')
    add_dir(' ','noop',0,ART+'skull_template.png',FANART,'')
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 UPDATE[/COLOR]','noop',0,ART+'kobrah24update.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'skull_template.png',FANART,'')
    add_dir('Kobra H24 minor update (Only use if auto update fails)',BASEURL+'minorupdate.zip',34,ART+'minorupdate1.png',FANART,'')
    add_dir('Kobra H24 major update (Only use if auto update fails)',BASEURL+'majorupdate.zip',50,ART+'majorupdate.png',FANART,'')
    add_dir(' ','noop',0,ART+'skull_template.png',FANART,'')
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 CUSTOMISATIONS[/COLOR]','noop',0,ART+'customisations.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'skull_template.png',FANART,'')
    add_dir('[COLOR ]Kobra H24 Background Packs[/COLOR]',BASEURL,24,ART+'backgroundpacks11.png',FANART,'')
    add_dir('[COLOR ]Kobra H24 Home Menu Packs[/COLOR]',BASEURL,99,ART+'homemenupacks11.png',FANART,'')
    add_dir('[COLOR ]Kobra H24 Theme Packs[/COLOR]',BASEURL,26,ART+'themepacks11.png',FANART,'')
    add_dir('[COLOR ]Kobra H24 Icon Packs[/COLOR]',BASEURL,16,ART+'iconpacks11.png',FANART,'')
    add_dir(' ','noop',0,ART+'skull_template.png',FANART,'')
    set_view('files', 'MAIN')


##############################
### KOBRA H24 BUILD WIZARD ###
##############################

def kobra_h24_build_wizard():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 BUILD INSTALL AND INFORMATION[/COLOR]','noop',0,ART+'installinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'',FANART,'')

    link = open_url('http://kobracustombuilds.com/builds/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,url,5,ART+'kobrah241.png',ART+'bg2.jpg',description)
    add_dir('Click here to view kobra h24 install video','noop',42,ART+'kobrah24installvideo.png',ART+'bg2.jpg','')
    add_dir('Click here to view kobra h24 preview video','noop',41,ART+'kobrah24previewvideo.png',ART+'bg2.jpg','')
    add_dir('Click here to view kobra h24 image gallery','noop',41,ART+'kobrah24imagegallery.png',ART+'bg2.jpg','')
    add_dir(' ','noop',0,ART+'',FANART,'')
    add_dir('[COLOR lime][I]BUILD [/I][/COLOR] [COLOR ghostwhite] INFORMATION[/COLOR]','noop',0,ART+'buildinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'buildinfo.png',FANART,'')

    link = open_url('http://kobracustombuilds.com/adult/wizard/kobrah24buildinfo.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,'noop',0,ART+'buildinfo.png',ART+'bg2.jpg',description)
    add_dir(' ','noop',0,ART+'buildinfo.png',FANART,'')
    add_dir('[COLOR lime][I]VIDEO [/I][/COLOR] [COLOR ghostwhite] ADD-ONS[/COLOR]','noop',0,ART+'buildinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'buildinfo.png',FANART,'')

    link = open_url('http://kobracustombuilds.com/adult/wizard/kobrah24videoaddons.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,'noop',0,ART+'buildinfo.png',ART+'bg2.jpg',description)
    add_dir(' ','noop',0,ART+'buildinfo.png',FANART,'')
    add_dir('[COLOR lime][I]PROGRAM [/I][/COLOR] [COLOR ghostwhite] ADD-ONS[/COLOR]','noop',0,ART+'buildinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'buildinfo.png',FANART,'')

    link = open_url('http://kobracustombuilds.com/adult/wizard/kobrah24progeamaddons.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,'noop',0,ART+'buildinfo.png',ART+'bg2.jpg',description)
    add_dir(' ','noop',0,ART+'buildinfo.png',FANART,'')
    set_view('files', 'MAIN')


########################
### KOBRA H24 VIDEOS ###
########################

def kobra_h24_install_video():
    X( "PlayMedia(http://kobracustombuilds.com/adult/video/install_tutorial.mp4)" )
    pass

def kobra_h24_preview_video():
    X( "PlayMedia(http://kobracustombuilds.com/adult/video/install_tutorial.mp4)" )
    pass


#######################################
### KOBRA XXX STREAM WINDOWS WIZARD ###
#######################################

def kobra_xxx_stream_wizard():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM[/COLOR]','noop',0,ART+'kobraxxx.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'xxxtemplate.png',FANART,'')
    link = open_url('http://kobracustombuilds.com/adult/wizard/kobra_xxx_stream_windows_wizard.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,url,39,ART+'kobraxxxinstall.png',ART+'bg2.jpg',description)
    add_dir('Click Here to View Kobra XXX Stream Exe Document','noop',11,ART+'xxxappinfo.png',ART+'bg2.jpg','')
    add_dir('Click Here to View Kobra XXX Stream Install Video','noop',9,ART+'kobraxxxvideo.png',ART+'bg2.jpg','')
    add_dir('Click Here to View Kobra XXX Stream Preview Video','noop',10,ART+'kobraxxxpreviewvideo.png',ART+'bg2.jpg','')
    add_dir('Click Here to View Kobra XXX Stream Image Gallery','noop',49,ART+'kobraxxximagegallery.png',ART+'bg2.jpg','')
    add_dir(' ','noop',0,ART+'xxxtemplate.png',FANART,'')
    add_dir('[COLOR lime][I]APPLICATION [/I][/COLOR] [COLOR ghostwhite] INFORMATION[/COLOR]','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'xxxtemplate.png',FANART,'')

    link = open_url('http://kobracustombuilds.com/adult/wizard/windowsapplicationinformation.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,'noop',0,ART+'xxxappinfo.png',ART+'bg2.jpg',description)
    add_dir(' ','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir('[COLOR lime][I]VIDEO [/I][/COLOR] [COLOR ghostwhite] ADD-ONS[/COLOR]','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'xxxtemplate.png',FANART,'')

    link = open_url('http://kobracustombuilds.com/adult/wizard/videoaddons.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,'noop',0,ART+'xxxappinfo.png',ART+'bg2.jpg',description)
    add_dir(' ','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir('[COLOR lime][I]PROGRAM [/I][/COLOR] [COLOR ghostwhite] ADD-ONS[/COLOR]','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'xxxtemplate.png',FANART,'')

    link = open_url('http://kobracustombuilds.com/adult/wizard/programaddons.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,'noop',0,ART+'xxxappinfo.png',ART+'bg2.jpg',description)
    add_dir(' ','noop',0,ART+'xxxappinfo.png',FANART,'')
    set_view('files', 'MAIN')


#######################################
### KOBRA XXX STREAM WINDOWS VIDEOS ###
#######################################

def kobra_xxx_stream_install_video():
    X( "PlayMedia(http://kobracustombuilds.com/adult/video/install_tutorial.mp4)" )

def kobra_xxx_stream_build_info():
    text_boxes(KOBRA,"[CR][CR][COLOR red]Please note this is an ADULT ONLY application.[/COLOR][CR][CR][COLOR ghostwhite]Kobra XXX Stream is a standalone application based on Kodi built for Windows Operating Systems. There is also an Android version available that will only be visible within the wizard if you are using an Android based device[CR][CR]Kobra XXX Stream installs and saves data to it's own storage location that is located within the application. This is where the build data will be stored so there is no need to worry about any interference with your existing Kodi configuration.[/COLOR][CR][CR][CR][CR][COLOR lime]Please press back or click [COLOR grey]  X   [/COLOR]in the top left corner of this window to exit.[/COLOR]")

def kobra_xxx_stream_preview_video():
    X( "PlayMedia(http://kobracustombuilds.com/adult/video/install_tutorial.mp4)" )

def kobra_xxx_stream_preview_gallery():
    X( "PlayMedia(http://kobracustombuilds.com/adult/video/kobra_xxx_stream_install_gallery.mp4)" )


#######################################
### KOBRA XXX STREAM ANDROID WIZARD ###
#######################################

def kobra_xxx_stream_android_wizard():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]XXX STREAM[/COLOR]','noop',0,ART+'kobraxxx.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'kobraxxx.png',FANART,'')
    link = open_url('http://kobracustombuilds.com/adult/wizard/kobra_xxx_stream_android_wizard.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,url,32,ART+'kobraxxxinstall.png',ART+'bg2.jpg',description)
    add_dir('Click Here to View Kobra XXX Stream Apk Document','noop',47,ART+'xxxappinfo.png',ART+'bg2.jpg','')
    add_dir('Click Here to View Kobra XXX Stream Install Video','noop',48,ART+'kobraxxxvideo.png',ART+'bg2.jpg','')
    add_dir('Click Here to View Kobra XXX Stream Preview Video','noop',10,ART+'kobraxxxpreviewvideo.png',ART+'bg2.jpg','')
    add_dir('Click Here to View Kobra XXX Stream Image Gallery','noop',49,ART+'imagegallery.png',ART+'bg2.jpg','')
    add_dir(' ','noop',0,ART+'kobraxxx.png',FANART,'')
    add_dir('[COLOR lime][I]APPLICATION [/I][/COLOR] [COLOR ghostwhite] INFORMATION[/COLOR]','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'xxxappinfo.png',FANART,'')

    link = open_url('http://kobracustombuilds.com/adult/wizard/androidapplicationinformation.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,'noop',0,ART+'xxxappinfo.png',ART+'bg2.jpg',description)
    add_dir(' ','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir('[COLOR lime][I]VIDEO [/I][/COLOR] [COLOR ghostwhite] ADD-ONS[/COLOR]','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'xxxappinfo.png',FANART,'')

    link = open_url('http://kobracustombuilds.com/adult/wizard/videoaddons.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,'noop',0,ART+'xxxappinfo.png',ART+'bg2.jpg',description)
    add_dir(' ','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir('[COLOR lime][I]PROGRAM [/I][/COLOR] [COLOR ghostwhite] ADD-ONS[/COLOR]','noop',0,ART+'xxxappinfo.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'xxxappinfo.png',FANART,'')

    link = open_url('http://kobracustombuilds.com/adult/wizard/programaddons.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,'noop',0,ART+'xxxappinfo.png',ART+'bg2.jpg',description)
    add_dir(' ','noop',0,ART+'xxxappinfo.png',FANART,'')
    set_view('files', 'MAIN')


#######################################
### KOBRA XXX STREAM ANDROID VIDEOS ###
#######################################

def kobra_xxx_stream_android_install_video():
    X( "PlayMedia(http://kobracustombuilds.com/adult/video/install_tutorial.mp4)" )

def kobra_xxx_stream_android_build_info():
    text_boxes(KOBRA2,"[CR][CR][COLOR red]Please note this is an ADULT ONLY application.[/COLOR][CR][CR][COLOR ghostwhite]Kobra XXX Stream is a standalone application based on Kodi built for Android OS. There is also a Windows version available that will only visible within the wizard if you are using a Windows based device.[CR][CR]Kobra XXX Stream installs and saves data to it's own storage location that is located within the application. This is where the build data will be stored so there is no need to worry about any interference with your existing Kodi configuration.[/COLOR][CR][CR][CR][COLOR lime]Please press back or click [COLOR grey]  X   [/COLOR]in the top left corner of this window to exit.[/COLOR]")


##################
### ICONS MENU ###
##################

def icons_menu():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 ICON PACKS[/COLOR]','noop',0,ART+'iconpacks11.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'',FANART,'')
    add_dir('Colour overlay icon packs',BASEURL,14,ART+'colouroverlay1.png',FANART,'')
    add_dir('Colour inner icon packs',BASEURL,18,ART+'colourpacks11.png',FANART,'')
    #add_dir('ANIMATED ICON PACKS (KODI-SPMC 16 OR ABOVE ONLY)',BASEURL,99,ART+'animatedicons11.png',FANART,'')
    #add_dir('USER SUBMITTED ICON PACKS',BASEURL,99,ART+'usersubmitted11.png',FANART,'')
    set_view('files', 'MAIN')


########################
### BACKGROUNDS MENU ###
########################

def backgrounds_menu():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 BACKGROUND PACKS[/COLOR]','noop',0,ART+'backgroundpacks11.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'',FANART,'')
    add_dir('Standard',BASEURL,23,ART+'standard11.png',FANART,'')
    add_dir('Animated (Kodi-Spmc 16 or above only)',BASEURL,99,ART+'animatedicons11.png',FANART,'')
    add_dir('User submitted packs',BASEURL,99,ART+'usersubmitted11.png',FANART,'')
    set_view('files', 'MAIN')


########################
### MAINTENANCE MENU ###
########################

def maintenance_menu():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]MAINTENANCE TOOLS[/COLOR]','noop',0,ART+'maintenance11.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'',FANART,'')
    #add_dir('CLEAR CRASH LOGS','url',45,ART+'deletecache11.png',FANART,'')
    add_dir('Delete packages','url',7,ART+'deletepackages11.png',FANART,'')
    #add_dir('Purge database','url',43,ART+'purgedatabase.png',FANART,'')
    add_dir('Force updates','url',44,ART+'forceupdates.png',FANART,'')
    add_dir('Delete cache','url',4,ART+'deletecache11.png',FANART,'')
    add_dir('Fresh start','url',6,ART+'freshstart11.png',FANART,'')
    set_view('files', 'MAIN')


############################
### BACKGROUND INSTALLER ###
############################

def background_installer(name,url,description):  
    if CONFIRM.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] BACKGROUND PACK INSTALLER[/COLOR]","[CR][COLOR ghostwhite]For use on Kobra H24 only![/COLOR]"," ","[COLOR ghostwhite]Would you like to install this background pack?[/COLOR]","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, INSTALL[/COLOR]"):
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] BACKGROUND PACK INSTALLER[/COLOR]",' ','',' ')
        lib=os.path.join(path, name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,"[CR][COLOR ghostwhite]Download complete[/COLOR]", "")
        T(1)
        DP.update(0,"","[COLOR ghostwhite]Installing backgrounds[/COLOR]")
        T(2)
        extract.all(lib,ADDON_FOLDER,DP)
        DP.close()
        clean_up()
        DIALOG.ok("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] BACKGROUND PACK INSTALLER[/COLOR]",'[CR][COLOR ghostwhite]Background pack [/COLOR][COLOR lime]installed[/COLOR]','[COLOR ghostwhite]Please click OK to apply the new backgrounds[/COLOR]')
        X('ReloadSkin()')
        T(1)
        X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  BACKGROUND PACK INSTALLER[/COLOR],[COLOR ghostwhite]Background pack successfully applied[/COLOR],5000,special://home/addons/plugin.video.kobrawizard/icon.png)')
    else: pass


###########################
### MINOR UPDATE WIZARD ###
###########################

def minor_update(name,url,description):
    if CONFIRM.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] MINOR UPDATE[/COLOR]","[CR][COLOR ghostwhite]For use on Kobra H24 only[/COLOR]"," ","[COLOR ghostwhite]Would you like to install this update?[/COLOR]","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, INSTALL[/COLOR]"):
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] MINOR UPDATE[/COLOR]",' ','',' ')
        lib=os.path.join(path, name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,"[CR][COLOR ghostwhite]Download complete[/COLOR]", "")
        T(1)
        DP.update(0,"","[COLOR ghostwhite]Installing update[/COLOR]")
        T(2)
        extract.all(lib,ADDON_FOLDER,DP)
        DP.close()
        clean_up()
        DIALOG.ok('[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] MINOR UPDATE[/COLOR]','[CR][COLOR ghostwhite]Minor update [COLOR ghostwhite][COLOR lime]successful[/COLOR]','[CR][COLOR ghostwhite]Click OK to apply the update[/COLOR]')
        X('ReloadSkin()')
        T(2)
        exit()
        T(5)
        X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  MINOR UPDATE[/COLOR],[COLOR ghostwhite]Update successfully applied[/COLOR],5000,special://home/addons/plugin.video.kobrawizard/icon.png)')
    else: pass

###########################
### MAJOR UPDATE WIZARD ###
###########################

def major_update(name,url,description):
    if CONFIRM.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] MAJOR UPDATE[/COLOR]","[CR][COLOR ghostwhite]For use on Kobra H24 only[/COLOR]"," ","[COLOR ghostwhite]Would you like to install this update?[/COLOR]","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, INSTALL[/COLOR]"):
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] MAJOR UPDATE[/COLOR]",' ','',' ')
        lib=os.path.join(path, name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,"[CR][COLOR ghostwhite]Download complete[/COLOR]", "")
        T(1)
        DP.update(0,"","[COLOR ghostwhite]Installing update[/COLOR]")
        T(2)
        extract.all(lib,ADDON_FOLDER,DP)
        DP.close()
        DIALOG.ok('[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] MAJOR UPDATE[/COLOR]','[CR][COLOR ghostwhite]Minor update[/COLOR] [COLOR lime]successful[/COLOR]','[CR][COLOR ghostwhite]Click OK to continue[/COLOR]')
        clean_up()
        kill_xbmc()
    else: pass


###############################
### PAUL'S WIZARD INSTALLER ###
###############################

def sk2wizard():
    link = open_url('http://kobracustombuilds.com/sk2/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    add_dir('[COLOR lime][I]SK2 [/I][/COLOR][COLOR ghostwhite] MQ7 PIMPED BY PAULSK2[/COLOR]','noop',0,ART+'sk21.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'',FANART,'')
    for name,url,iconimage,fanart,description in match:
        add_dir(name,url,36,ART+'sk21.png',fanart,description)
    add_dir(' ','noop',0,ART+'',FANART,'')
    add_dir('[COLOR lime][I]BUILD [/I][/COLOR] [COLOR ghostwhite] INFORMATION[/COLOR]','noop',0,ART+'sk21.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'sk21.png',FANART,'')
    add_dir('Only use on a fresh installation of Kodi','noop',0,ART+'sk21.png',FANART,'')
    add_dir('Don not install over Kobra H24','noop',0,ART+'sk21.png',FANART,'')
    add_dir('Build size = 310mb','noop',0,ART+'sk21.png',FANART,'')
    add_dir('Adult content = Yes','noop',0,ART+'sk21.png',FANART,'')
    add_dir('Skin = MQ7','noop',0,ART+'sk21.png',FANART,'')
    set_view('files', 'MAIN')


#################################
### COLOR ICON PACK INSTALLER ###
#################################

def icon_pack_installer(name,url,description):
    if CONFIRM.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] ICON PACK INSTALLER[/COLOR]","[CR][COLOR ghostwhite]For use on Kobra H24 only"," ","Would you like to install this icon pack?[/COLOR]","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, INSTALL[/COLOR]"):
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] ICON PACK INSTALLER[/COLOR]",' ','',' ')
        lib=os.path.join(path, name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,"[CR][COLOR ghostwhite]Download complete[/COLOR]", "")
        T(1)
        DP.update(0,"","[COLOR ghostwhite]Installing icons[/COLOR]")
        T(2)
        extract.all(lib,ADDON_FOLDER,DP)
        DP.close()
        clean_up()
        DIALOG.ok('[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] ICON PACK INSTALLER[/COLOR]','[CR][COLOR ghostwhite]Installation[/COLOR] [COLOR lime]successful[/COLOR]','[CR][COLOR ghostwhite]Click OK to apply the new icon pack[/COLOR]')
        X('ReloadSkin()')
        T(2)
        X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ICON PACK INSTALLER[/COLOR],[COLOR ghostwhite]Icon pack successfully applied[/COLOR],5000,special://home/addons/plugin.video.kobrawizard/icon.png)')
    else: pass
#X("ActivateWindow(10000)")


#######################
### THEME INSTALLER ###
#######################

def theme_installer(name,url,description):
    if CONFIRM.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] THEME INSTALLER[/COLOR]","[CR][COLOR ghostwhite]For use on Kobra H24 only[/COLOR]"," ","[COLOR ghostwhite]Would you like to install this theme?[/COLOR]","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, INSTALL[/COLOR]"):
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create('[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] THEME INSTALLER[/COLOR]',' ','',' ')
        lib=os.path.join(path, name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,"[CR][COLOR ghostwhite]Download complete[/COLOR]", "")
        T(1)
        DP.update(0,"","[COLOR ghostwhite]Installing theme[/COLOR]")
        T(2)
        extract.all(lib,ADDON_FOLDER,DP)
        DP.close()
        clean_up()
        DIALOG.ok("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] THEME INSTALLER[/COLOR]",'[CR][COLOR ghostwhite]Installation[/COLOR] [COLOR lime]successful[/COLOR]','[CR][COLOR ghostwhite]Click OK to apply the new theme[/COLOR]')
        X('ReloadSkin()')
        T(2)
        X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  THEME PACK INSTALLER[/COLOR],[COLOR ghostwhite]Theme pack successfully applied[/COLOR],5000,special://home/addons/plugin.video.kobrawizard/icon.png)')
    else: pass


################################
### KOBRA XXX STREAM ANDROID ###
################################

def kobra_xxx_stream_android_installer(name,url,description):
    if DIALOG.yesno('[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] ADULT CONTENT DISCLAIMER[/COLOR]','[COLOR ghostwhite][CR]Kobra XXX Stream is designed for ADULTS only and may include pictures and materials that some viewers may find offensive. If you are under the age of 18, if such material offends you or if it is illegal to view such material in your community please exit this application.[/COLOR]','','[COLOR ghostwhite]The following terms and conditions apply to this application. Use of the application will constitute your agreement to the following terms and conditions:[CR][CR]1. I am 18 years of age or older.[CR]2. I accept all responsibility for my own actions.[CR]3. I agree that I am legally bound to these Terms and Conditions.[CR][CR]Click YES to agree to these terms and conditions or click NO to exit this application.[/COLOR]','[COLOR orange]NO, I DISAGREE[/COLOR]','[COLOR lime]YES, I AGREE[/COLOR]'):
        downloadpath = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite]XXX STREAM INSTALLER[/COLOR]"," ",' ',' ')
        lib=os.path.join(downloadpath, 'Kobra_XXX_Stream'+'.apk')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        DP.close()
        DIALOG.ok("[COLOR lime][I]KOBRA  [/I][/COLOR][COLOR ghostwhite]XXX STREAM INSTALLER[/COLOR]"," ","[COLOR ghostwhite]Apk download complete[/COLOR]","[COLOR ghostwhite]Click OK to install Kobra XXX Stream[/COLOR]")
        #][NT3L]I[G3NC][# 
        X('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+lib+'")')
        T(4)
        clean_up()
        DIALOG.ok("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] XXX STREAM INSTALLER[/COLOR]",'[CR][COLOR ghostwhite]Application[/COLOR] [COLOR lime]installed[/COLOR]','[CR][COLOR ghostwhite]Click OK to continue[/COLOR]')
    else: pass


################################
### KOBRA XXX STREAM WINDOWS ###
################################

def kobra_xxx_windows(name,url,description):
    if DOWNLOADPATH == '' or not os.path.exists(DOWNLOADPATH): 
        DIALOG.ok(KOBRA, "[COLOR ghostwhite][CR]You will need to setup a downloads path before you can install Kobra XXX Stream. Click OK to continue[/COLOR]")
        settings(ADDON_ID, 4.0, True)
    else:
        if DIALOG.yesno('[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] ADULT CONTENT DISCLAIMER[/COLOR]','[COLOR ghostwhite][CR]Kobra XXX Stream is designed for ADULTS only and may include pictures and materials that some viewers may find offensive. If you are under the age of 18, if such material offends you or if it is illegal to view such material in your community please exit this application.[/COLOR]','','[COLOR ghostwhite]The following terms and conditions apply to this application. Use of the application will constitute your agreement to the following terms and conditions:[CR][CR]1. I am 18 years of age or older.[CR]2. I accept all responsibility for my own actions.[CR]3. I agree that I am legally bound to these Terms and Conditions.[CR][CR]Click YES to agree to these terms and conditions or click NO to exit this application.[/COLOR]','[COLOR orange]NO, I DISAGREE[/COLOR]','[COLOR lime]YES, I AGREE[/COLOR]'):
            DP.create(KOBRA)
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'KOBRA-XXX-STREAM')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'KOBRA-XXX-STREAM'))
                except: DIALOG.ok(ADDON_TITLE, '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]'); setS('downloads', ""); ADDON.openSettings(); return
            if not os.path.exists(os.path.join(DOWNLOADPATH, 'KOBRA-XXX-STREAM')): 
                try: os.makedirs(os.path.join(DOWNLOADPATH, 'KOBRA-XXX-STREAM'))
                except: DIALOG.ok(ADDON_TITLE, '[COLOR red]Error writing to download path![/COLOR]', '[COLOR ghostwhite]Please select another download location and Check Path[/COLOR]', '[COLOR ghostwhite]Failed to create[/COLOR]: %s' % os.path.join(DOWNLOADPATH, 'KOBRA-XXX-STREAM'));  return
            lib=os.path.join(DOWNLOADPATH, 'KOBRA-XXX-STREAM', name+'.zip')
            downloader.download(url, lib, DP)
            T(2)
            DP.update(0,"[CR][COLOR ghostwhite]Download complete[/COLOR]", "")
            T(1)
            DP.update(0,"","[COLOR ghostwhite]Installing Kobra XXX Stream[/COLOR]")
            extract.all(lib,WINDOWSAPPSPATH,DP)
            DP.close()
            try: os.remove(lib)
            except: pass
            confirm=xbmcgui.Dialog()
            if confirm.yesno(KOBRA," ","[COLOR ghostwhite]Installation[/COLOR] [COLOR lime]successful[/COLOR]","[COLOR ghostwhite]Would you like to open your downloads folder and then exit Kodi/Spmc?[/COLOR]","[COLOR orange]NO, CLOSE & GO BACK[/COLOR]","[COLOR lime]YES, OPEN & EXIT[/COLOR]"):
                T(2)
                X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  FORCE CLOSE[/COLOR],[COLOR ghostwhite]Smell you later. Bye bye[/COLOR],10000,special://home/addons/plugin.video.kobrawizard/icon.png)')
                T(4)
                #os.startfile(OPENPATH)  #TESTING
                subprocess.Popen(r'explorer /select,"%s"' % OPENPATH)
                T(2)
                os._exit(1)
                #xbmc.executebuiltin('Quit') # possible on next update
            else: pass
        else: pass


########################################
### MICELLANEOUS ICON PACK INSTALLER ###
########################################

def colour_innsericon_pack_installer(name,url,description):
    if CONFIRM.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] ICON PACK INSTALLER[/COLOR]","[CR][COLOR ghostwhite]For use on Kobra H24 only[/COLOR]"," ","[COLOR ghostwhite]Install this icon pack?[/COLOR]","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, INSTALL[/COLOR]"):
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create('[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] ICON PACK INSTALLER[/COLOR]',' ','',' ')
        lib=os.path.join(path, name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,"[CR][COLOR ghostwhite]Download complete[/COLOR]", "")
        T(1)
        DP.update(0,"","[COLOR ghostwhite]Installing icons[/COLOR]")
        T(2)
        extract.all(lib,ADDON_FOLDER,DP)
        DP.close()
        clean_up()
        DIALOG.ok('[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] ICON PACK INSTALLER[/COLOR]','[CR][COLOR ghostwhite]Installation[/COLOR] [COLOR lime]successful[/COLOR]','[CR][COLOR ghostwhite]Click OK to apply the new icons[/COLOR]')
        X('ReloadSkin()')
        T(2)
        X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  ICON PACK INSTALLER[/COLOR],[COLOR ghostwhite]Icon pack successfully applied[/COLOR],5000,special://home/addons/plugin.video.kobrawizard/icon.png)')
    else: pass


####################
### THEME WIZARD ###
####################

def theme_wizard():
    link = open_url('http://kobracustombuilds.com/tools/themes/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 THEME PACKS[/COLOR]','noop',0,ART+'themepacks11.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'',FANART,'')
    for name,url,iconimage,fanart,description in match:
        add_dir(name,url,27,iconimage,fanart,description)
    add_dir('More coming soon','noop',0,ART+'comingsoon.png',ART+'bg2.jpg','')
    set_view('files', 'MAIN')


###########################
### COLOUR ICONS WIZARD ###
###########################

def colour_overlay_icons():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 ICON PACKS[/COLOR]','noop',0,ART+'kobrawizard.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'',FANART,'')
    link = open_url('http://kobracustombuilds.com/tools/iconpacks/colourpacks/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,url,13,iconimage,fanart,description)
    add_dir('More coming soon','noop',0,ART+'comingsoon.png',ART+'bg2.jpg','')
    set_view('files', 'MAIN')


#################################
### MICELLANEOUS ICONS WIZARD ###
#################################

def colour_inner_icons_wizard():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 ICON PACKS[/COLOR]','noop',0,ART+'kobrawizard.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'',FANART,'')
    link = open_url('http://kobracustombuilds.com/tools/iconpacks/miscellaneous/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,url,17,iconimage,fanart,description)
    add_dir('More coming soon','noop',0,ART+'comingsoon.png',ART+'bg2.jpg','')
    set_view('files', 'MAIN')

#########################
### BACKGROUND WIZARD ###
#########################

def background_wizard():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]H24 BACKGROUND PACKS[/COLOR]','noop',0,ART+'kobrawizard.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'',FANART,'')
    link = open_url('http://kobracustombuilds.com/tools/backgrounds/wizard/wizard.txt').replace('\n','').replace('\r','')
    match = re.compile(REGEX).findall(link)
    for name,url,iconimage,fanart,description in match:
        add_dir(name,url,22,iconimage,fanart,description)
    add_dir('More coming soon','noop',0,ART+'comingsoon.png',ART+'bg2.jpg','')
    set_view('files', 'MAIN')


################
### OPEN URL ###
################

def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link


##################
### TEXT BOXES ###
##################

def text_boxes(heading,announce):
    class TextBox():
        WINDOW=10147
        CONTROL_LABEL=1
        CONTROL_TEXTBOX=5
        def __init__(self,*args,**kwargs):
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
            self.win=xbmcgui.Window(self.WINDOW) # get window
            xbmc.sleep(500) # give window time to initialize
            self.setControls()
        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
            try: f=open(announce); text=f.read()
            except: text=announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return
    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        T(.5)

###################
### COMING SOON ###
###################

def coming_soon():
    add_dir('[COLOR lime][I]KOBRA [/I][/COLOR] [COLOR ghostwhite]COMING SOON[/COLOR]','noop',0,ART+'comingsoon.png',FANART,'')
    add_dir(DIVIDE,'noop',0,ART+'comingsoon.png',FANART,'')
    add_dir('Coming soon','noop',0,ART+'comingsoon.png',ART+'bg2.jpg','')
    set_view('files', 'MAIN')


###############
### CONTACT ###
###############

def contact():
    X("RunAddon(plugin.program.kobra.notifications)")


#####################
### VIDEO PREVIEW ###
#####################

def video_preview():
    X("RunAddon(plugin.video.kobra.tube)")


#####################
### APP INSTALLER ###
#####################

def kobra_app_installer():
    X("RunAddon(program.kobra.app.installer)")


################
### SETTINGS ###
################

def open_settings():
    ADDON.openSettings()
    X('Container.Refresh')

def settings(id=ADDON_ID, focus=None, click=False):
    try:
        X('Addon.OpenSettings(%s)' % id)
        value1, value2 = str(focus).split('.')
        X('SetFocus(%d)' % (int(value1) + 100))
        X('SetFocus(%d)' % (int(value2) + 200))
        if click == True: X('SendClick(%s)' % (int(value2) + 200))
    except:
        return
        
def getS(name):
    try: return ADDON.getSetting(name)
    except: return False

def setS(name, value):
    try: ADDON.setSetting(name, value)
    except: return False


#####################
### APP UNINSTALL ###
#####################

#def APPUNINSTALL():
    #X('StartAndroidActivity("","android.intent.action.DELETE","","package:com.robbzkiill3r.iint3liig3ncii")')
    #main_menu()
    #X('StartAndroidActivity(,android.intent.action.VIEW,,url:http://kodi.tv)')
    #X('StartAndroidActivity(com.android.apphere,android.intent.action.VIEW,,http://pathhere/)')
    #os.system('am start --user 0 -a android.intent.action.VIEW -d http://kodi.tv -n com.estrongs.android.pop/.view.FileExplorerActivity')


####################
### BUILD WIZARD ###
####################

def build_wizard(name,url,description):
    if CONFIRM.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] BUILD INSTALLER[/COLOR]","[CR][COLOR ghostwhite]Kobra H24 build[/COLOR]","[COLOR ghostwhite]Only use on a fresh installaion[/COLOR]","[COLOR ghostwhite]Would you like to install this build?[/COLOR]","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, INSTALL[/COLOR]"):
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] BUILD INSTALLER[/COLOR]",' ','',' ')
        lib=os.path.join(path, name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,"[CR][COLOR ghostwhite]Download complete[/COLOR]", "")
        T(1)
        DP.update(0,"","[COLOR ghostwhite]Installing build[/COLOR]")
        T(2)
        extract.all(lib,ADDON_FOLDER,DP)
        DP.close()
        clean_up()
        kill_xbmc()
    else: pass


########################
### SK2 BUILD WIZARD ###
########################

def sk2_wizard(name,url,description):
    if CONFIRM.yesno("[COLOR lime][I]SK2 [/I][/COLOR][COLOR ghostwhite] BUILD INSTALLER[/COLOR]","[CR][COLOR ghostwhite]Only use on a fresh install[/COLOR]"," ","[COLOR ghostwhite]Would you like to install this build?[/COLOR]","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, INSTALL[/COLOR]"):
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        DP.create("[COLOR lime][I]SK2 [/I][/COLOR][COLOR ghostwhite] BUILD INSTALLER[/COLOR]",' ','',' ')
        lib=os.path.join(path, name+'.zip')
        try: os.remove(lib)
        except: pass
        downloader.download(url, lib, DP)
        T(2)
        DP.update(0,"[CR][COLOR ghostwhite]Download complete[/COLOR]", "")
        T(1)
        DP.update(0,"","[COLOR ghostwhite]Installing sk2 build[/COLOR]")
        T(2)
        extract.all(lib,ADDON_FOLDER,DP)
        DP.close()
        clean_up()
        kill_xbmc()
    else: pass

############################
###  CLEAN UP PACKAGES  ####
### THANKS GUYS @ XUNITY ###
############################

def clean_up():
    PACKAGES = xbmc.translatePath('special://home/addons/packages')
    if os.path.exists(PACKAGES):
        try:
            for root, dirs, files in os.walk(PACKAGES):
                file_count = 0
                file_count += len(files)
                # Count files and give option to delete
                if file_count > 0:
                    if DIALOG.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] FILE CLEANER[/COLOR]"," ", "[COLOR ghostwhite]{0} files found, [CR][CR]Would you like to remove them?[/COLOR]".format(file_count),"","[COLOR orange]NO, GO BACK[/COLOR]","[COLOR lime]YES, REMOVE[/COLOR]"):
                        for f in files: os.unlink(os.path.join(root, f))
                        for d in dirs: shutil.rmtree(os.path.join(root, d))
                        DIALOG.ok(ADDON_TITLE3,'[CR][CR][COLOR ghostwhite]Clean up files:[/COLOR] [COLOR lime] Successful[/COLOR]')
                else: DIALOG.ok(ADDON_TITLE3,'[CR][CR][COLOR ghostwhite]Clean up files:[/COLOR] [COLOR red]No files found[/COLOR]')
        except: DIALOG.ok(ADDON_TITLE3,'[CR][CR][COLOR ghostwhite]Clean up files:[/COLOR] [COLOR red] ! Error ![/COLOR]')
    else: DIALOG.ok(ADDON_TITLE3,'[CR][CR][COLOR ghostwhite]Clean up files:[/COLOR] [COLOR red] NO files found[/COLOR]')



############################
###     DELETE CACHE     ###
### THANKS GUYS @ XUNITY ###
############################

def delete_cache_files(url):
    xbmc.log("Kobra: deleting standard cache")
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)

        # Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] DELETE CACHE FILES[/COLOR]"," ", "[COLOR ghostwhite]{0} files found, [CR]Would you like to remove them?[/COLOR]".format(file_count)):

                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass

            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')

        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):

                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))

            else:
                pass
              # Set path to Cydia Archives cache files
    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
        # Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):

                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
            else:
                pass
                # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)

        # Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("[COLOR ghostwhite]Delete 4oD Cache Files[/COLOR]", str(file_count) + " [COLOR ghostwhite]files found[/COLOR]", "[COLOR ghostwhite]Do you want to delete them?[/COLOR]"):
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))

            else:
                pass

                # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)

        # Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("Delete BBC iPlayer Cache Files", str(file_count) + "[COLOR ghostwhite] files found", "Do you want to delete them?[/COLOR]"):

                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))

            else:
                pass


                # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)

        # Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] Delete simple downloader cache files[/COLOR]", str(file_count) + " [COLOR ghostwhite]files found", "Do you want to delete them?[/COLOR]"):

                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))

            else:
                pass

                # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)

        # Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] Delete itv cache files[/COLOR]", str(file_count) + " [COLOR ghostwhite]files found", "Do you want to delete them?[/COLOR]"):

                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))

            else:
                pass

                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)

        # Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] Delete temp dir cache files[/COLOR]", str(file_count) + " [COLOR ghostwhite]files found", "Do you want to delete them?[/COLOR]"):

                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))

            else:
                pass
    DIALOG.ok("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] DELETE CACHE FILES[/COLOR]", "[CR][COLOR ghostwhite]All cache files have been removed","", "Click OK to continue[/COLOR]")


########################
### FORCE CLOSE KODI ###
########################

def kill_xbmc():
    DIALOG.ok("[COLOR lime]KOBRA [/COLOR][COLOR ghostwhite]FORCE CLOSE[/COLOR]", "[COLOR ghostwhite][CR]We now need to force close kodi/Spmc for the changes to be applied. Please restart the application.  Click OK to continue[/COLOR]")
    xbmc.log("Force Closing Kodi")
    T(1)
    X('Notification([COLOR lime][I]KOBRA[/I][/COLOR][COLOR ghostwhite]  FORCE CLOSE[/COLOR],[COLOR ghostwhite]Smell you later. Bye bye[/COLOR],5000,special://home/addons/plugin.video.kobrawizard/icon.png)')
    T(6)
    os._exit(1)
 
 
#################################
### ACTIVATE HOME AND REFRESH ###
#################################

def exit():
    X("Container.Update(path,replace)")
    X(RETURN)

##########################
### DETERMINE PLATFORM ###
##########################

def platform():
    if xbmc.getCondVisibility('system.platform.android')    : return 'android'
    elif xbmc.getCondVisibility('system.platform.linux')    : return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows')  : return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx')      : return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2')     : return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios')      : return 'ios'


############################
####### FRESH START ########
#### THANKS TO TVADDONS ####
############################

def fresh_start(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] FRESH START[/COLOR]","[COLOR ghostwhite]Do you wish to restore your Kodi-Spmc configuration to default settings?[/COLOR][CR][COLOR red] WARNING [/COLOR][COLOR ghostwhite]All your data will be lost and not recoverable.[/COLOR][CR][COLOR red] Would you like to proceed?[/COLOR]")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath);
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(ADDON_TITLE,"The process is complete, you're now back to a fresh Kodi-SPMC configuration with Kobra Wizard!","Please reboot your system or restart Kodi-SPMC in order for the changes to be applied.")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message("[COLOR grey2]FRESH START[/COLOR]","THE PROCESS IS COMPLETE, YOU ARE NOW BACK TO A FRESH KODI-SPMC CONFIGURATION.","PLEASE REBOOT YOUR SYSTEM OR RESTART KODI-SPMC FOR THE CHANGES TO BE APPLIED.")
        except: plugintools.message(ADDON_TITLE,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Now Exit Kodi",folder=False)
    else: DIALOG.ok("[COLOR lime][I]KOBRA [/I][/COLOR][COLOR ghostwhite] FRESH START[/COLOR]", "[COLOR ghostwhite][CR]No changes have been made[/COLOR]","", "[COLOR ghostwhite]Click OK to return to previous menu[/COLOR]")


######################
### PURGE DATABASE ###
######################

def purgeDb(name):
    #dbfile = name.replace('.db','').translate(None, digits)
    #if dbfile not in ['Addons', 'ADSP', 'Epg', 'MyMusic', 'MyVideos', 'Textures', 'TV', 'ViewModes']: return False
    #textfile = os.path.join(DATABASE, name)
    LOG('Purging DB %s.' % name)
    if os.path.exists(name):
        try:
            textdb = database.connect(name)
            textexe = textdb.cursor()
        except Exception, e:
            LOG(str(e))
            return False
    else: LOG('%s not found.' % name); return False
    textexe.execute("""SELECT name FROM sqlite_master WHERE type = 'table';""")
    for table in textexe.fetchall():
        if table[0] == 'version': 
            LOG('Data from table `%s` skipped.' % table[0])
        else:
            try:
                textexe.execute("""DELETE FROM %s""" % table[0])
                textdb.commit()
                LOG('Data from table `%s` cleared.' % table[0])
            except e: LOG(str(e))
    LOG('%s DB Purging Complete.' % name)
    show = name.replace('\\', '/').split('/')
    log_notify("Purge Database", "%s Complete" % show[len(show)-1])


#####################
### FORCE UPDATES ###
#####################

def force_update():
    X('UpdateAddonRepos()')
    X('UpdateLocalAddons()')
    log_notify(ADDON_TITLE, '[COLOR ghostwhite]Forcing Addon Updates[/COLOR]')

def log_notify(title,message,times=5000,icon=ICON):
    xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % (title , message , times, icon))

def LOG(log):
    xbmc.log("[%s]: %s" % (ADDON_TITLE, LOG))
    if not os.path.exists(ADDONDATA): os.makedirs(ADDONDATA)
    if not os.path.exists(WIZLOG): f = open(WIZLOG, 'w'); f.close()
    with open(WIZLOG, 'a') as f:
        line = "[%s %s] %s" % (datetime.now().date(), str(datetime.now().time())[:8], LOG)
        f.write(line.rstrip('\r\n')+'\n')

def clear_crash():  
    files = []
    for file in glob.glob(os.path.join(LOG, 'xbmc_crashlog*.*')):
        files.append(file)
    if len(files) > 0:
        if DIALOG.yesno(ADDON_TITLE, 'Would you like to delete the Crash logs?', '%s Files Found' % len(files)):
            for f in files:
                os.remove(f)
            LogNotify('Clear Crash Logs', '%s Files Removed' % len(files))
        else: LogNotify('Clear Crash Logs', 'Cancelled')
    else: LogNotify('Clear Crash Logs', 'No Files Found')
    
def check_colour():
	if name.startswith("[COLOR"):
		basename = re.sub("\[COLOR=.+?\](.*)\[/COLOR\]", "\\1", name)
	else:
		basename = name

##############
### VOODOO ###
##############

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
           params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
               param[splitparams[0]]=splitparams[1]
    return param


#####################
### ADD DIRECTORY ###
#####################

def add_dir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    if mode==4 or mode==5 or mode==6 or mode==7 or mode==8 or mode==9 or mode==10 or mode==13 or mode==17 or mode==20 or mode==22 or mode==27 or mode==28 or mode==30 or mode==31 or mode==32 or mode==34 or mode==35 or mode==36 or mode==37 or mode==39 or mode==41 or mode==42 or mode==43 or mode==44 or mode==50 or mode==51 or url=='noop':
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


params          = get_params()
url             = None
name            = None
mode            = None
iconimage       = None
fanart          = None
description     = None


try     : url=urllib.unquote_plus(params["url"])
except  : pass

try     : name=urllib.unquote_plus(params["name"])
except  : pass

try     : iconimage=urllib.unquote_plus(params["iconimage"])
except  : pass

try     : mode=int(params["mode"])
except  : pass

try     : fanart=urllib.unquote_plus(params["fanart"])
except  : pass

try     : description=urllib.unquote_plus(params["description"])
except  : pass


print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def set_view(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), 'files')
    if ADDON.getSetting('auto-view')=='true':
        X("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )


if mode==None:  check_download_path()

elif mode==2:   kobra_h24_build_menu()
       
elif mode==3:   maintenance_menu()
        
elif mode==4:   delete_cache_files(url)
     
elif mode==5:   build_wizard(name,url,description)

elif mode==6:   fresh_start(params)

elif mode==7:   clean_up()

elif mode==8:   contact()

elif mode==9:   kobra_xxx_stream_install_video()

elif mode==10:  kobra_xxx_stream_preview_video()

elif mode==11:  kobra_xxx_stream_build_info()

elif mode==12:  ANDROID_BUILD_MENU()

elif mode==13:  icon_pack_installer(name,url,description)

elif mode==14:  colour_overlay_icons()

elif mode==16:  icons_menu()

elif mode==17:  colour_innsericon_pack_installer(name,url,description)

elif mode==18:  colour_inner_icons_wizard()

elif mode==19:  APP_INSTALLER_MENU()

elif mode==20:  ANDROIDAPPSINSTALLER(name,url,description)

elif mode==22:  background_installer(name,url,description)

elif mode==23:  background_wizard()

elif mode==24:  backgrounds_menu()

elif mode==25:  THEMEMENU()

elif mode==26:  theme_wizard()

elif mode==27:  theme_installer(name,url,description)

elif mode==28:  kobra_app_installer()

elif mode==29:  VIDEOMENU()

elif mode==30:  video_preview()

elif mode==31:  intro()

elif mode==32:  kobra_xxx_stream_android_installer(name,url,description)

elif mode==33:  sk2wizard()

elif mode==34:  minor_update(name,url,description)

elif mode==35:  BUILD_UPDATER(name,url,description)

elif mode==36:  sk2_wizard(name,url,description)

elif mode==37:  open_settings()

elif mode==38:  kobra_h24_build_wizard()

elif mode==39:  kobra_xxx_windows(name,url,description)

elif mode==40:  kobra_xxx_stream_wizard()

elif mode==41:  kobra_h24_install_video()

elif mode==42:  kobra_h24_preview_video()

elif mode==43:  purgeDb(name)

elif mode==44:  force_update()

elif mode==45:  clear_crash()

elif mode==46:  kobra_xxx_stream_android_wizard()

elif mode==47:  kobra_xxx_stream_android_build_info()

elif mode==48:  kobra_xxx_stream_android_install_video()

elif mode==49:  kobra_xxx_stream_preview_gallery()

elif mode==50:  major_update(name,url,description)

elif mode==51:  new_features1()

elif mode==99:  coming_soon()



xbmcplugin.endOfDirectory(int(sys.argv[1]))