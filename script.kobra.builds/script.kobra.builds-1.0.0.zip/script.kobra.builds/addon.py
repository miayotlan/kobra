﻿import xbmcaddon
import xbmcgui
 
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
 
line1 = "WELCOME TO KOBRA CUSTOM BUILDS"
line2 = "SKIN: KOBRA H24"
line3 = "BUILD: V3.3"
 
xbmcgui.Dialog().ok(addonname, line1, line2, line3)